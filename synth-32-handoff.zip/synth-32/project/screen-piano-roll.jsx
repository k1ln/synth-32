/* global React, MiniTopBar, Drop, Icon, Knob */

// ===================================================================
//   PIANO ROLL EDITOR
// ===================================================================

// 24-row pitch range, top-down (high to low). MIDI notes.
const TOP_NOTE = 72;     // C5
const ROW_COUNT = 20;
const BARS_VISIBLE = 2;
const TICKS_PER_BAR = 384;        // 4/4 @ 96 PPQN
const TICKS_VISIBLE = TICKS_PER_BAR * BARS_VISIBLE;

const NOTE_NAMES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
const isBlack = n => [1,3,6,8,10].includes(n % 12);
const noteLabel = n => `${NOTE_NAMES[n%12]}${Math.floor(n/12)-1}`;

// Bass-style melody: tick, len, note, vel
const NOTES = [
  { tick: 0,    len: 96,  note: 40, vel: 100 },
  { tick: 96,   len: 48,  note: 43, vel: 90  },
  { tick: 144,  len: 48,  note: 47, vel: 95  },
  { tick: 192,  len: 96,  note: 52, vel: 110 },
  { tick: 288,  len: 48,  note: 50, vel: 88  },
  { tick: 336,  len: 48,  note: 47, vel: 90  },

  { tick: 384,  len: 96,  note: 40, vel: 100 },
  { tick: 480,  len: 48,  note: 43, vel: 92  },
  { tick: 528,  len: 48,  note: 45, vel: 95  },
  { tick: 576,  len: 96,  note: 48, vel: 105 },
  { tick: 672,  len: 48,  note: 50, vel: 95  },
  { tick: 720,  len: 48,  note: 52, vel: 100 },
];

const PLAYHEAD_TICK = 220;

const PianoRollEditor = () => {
  const rowH = 24;
  const rollH = ROW_COUNT * rowH;
  const keyW = 64;
  const rollW = 1280 - keyW;
  const tickToPx = t => (t / TICKS_VISIBLE) * rollW;

  return (
    <div className="frame">
      <MiniTopBar
        title="Bass · Lane 02"
        right={
          <>
            <Drop label="SYNTH" value="Subtractive Mono" w={210} />
            <Drop label="SNAP"  value="1/16" w={120} />
            <Drop label="ZOOM"  value="2 bars" w={130} />
          </>
        }
      />

      <div className="pr-area">
        {/* Bar header */}
        <div className="pr-bar-header" style={{ height: 28 }}>
          <div style={{ width: keyW, borderRight: "1px solid var(--line)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="wave" size={12} />
          </div>
          <div style={{ flex: 1, position: "relative" }}>
            {/* Bar/beat markers */}
            {Array.from({ length: BARS_VISIBLE * 4 }).map((_, beat) => {
              const isBar = beat % 4 === 0;
              const x = (beat / (BARS_VISIBLE * 4)) * rollW;
              const label = isBar ? `BAR ${beat/4 + 1}` : `${(beat%4) + 1}`;
              return (
                <div key={beat} style={{
                  position: "absolute", left: x, top: 0, bottom: 0,
                  borderLeft: `1px solid ${isBar ? "var(--line-3)" : "var(--line)"}`,
                  padding: "5px 0 0 6px",
                  fontFamily: "var(--f-mono)",
                  fontSize: 9,
                  letterSpacing: "0.1em",
                  color: isBar ? "var(--t1)" : "var(--t3)",
                  textTransform: "uppercase",
                }}>
                  {label}
                </div>
              );
            })}
            {/* Playhead */}
            <div style={{ position: "absolute", left: tickToPx(PLAYHEAD_TICK), top: 0, bottom: 0, width: 1, background: "var(--lime)" }}/>
            <div style={{ position: "absolute", left: tickToPx(PLAYHEAD_TICK) - 14, top: 4, color: "var(--lime)", fontFamily: "var(--f-mono)", fontSize: 9, padding: "1px 4px", background: "var(--bg-1)" }}>
              ▸
            </div>
          </div>
        </div>

        {/* Roll body */}
        <div className="pr-body" style={{ flex: 1, display: "flex", position: "relative", overflow: "hidden" }}>
          {/* Piano key column */}
          <div className="pr-keys" style={{ width: keyW, borderRight: "1px solid var(--line-2)", background: "var(--bg-2)" }}>
            {Array.from({ length: ROW_COUNT }).map((_, i) => {
              const n = TOP_NOTE - i;
              const blk = isBlack(n);
              return (
                <div key={i} className={`pr-key ${blk ? "black" : "white"}`} style={{ height: rowH }}>
                  <span>{noteLabel(n)}</span>
                </div>
              );
            })}
          </div>

          {/* Note grid */}
          <div className="pr-grid" style={{ flex: 1, position: "relative", background: "var(--bg-1)" }}>
            {/* Horizontal rows (background tint per pitch row) */}
            {Array.from({ length: ROW_COUNT }).map((_, i) => {
              const n = TOP_NOTE - i;
              const blk = isBlack(n);
              return (
                <div key={i} style={{
                  position: "absolute",
                  left: 0, right: 0,
                  top: i * rowH,
                  height: rowH,
                  background: blk ? "rgba(255,255,255,0.012)" : "transparent",
                  borderBottom: "1px solid rgba(255,255,255,0.025)",
                }}/>
              );
            })}

            {/* Vertical grid lines (16ths) */}
            {Array.from({ length: BARS_VISIBLE * 16 }).map((_, i) => {
              const x = (i / (BARS_VISIBLE * 16)) * rollW;
              const isBar = i % 16 === 0;
              const isBeat = i % 4 === 0;
              return (
                <div key={i} style={{
                  position: "absolute",
                  left: x, top: 0, bottom: 0,
                  width: 1,
                  background: isBar ? "var(--line-3)" : isBeat ? "var(--line-2)" : "var(--line)",
                  opacity: isBar ? 0.9 : isBeat ? 0.6 : 0.4,
                }}/>
              );
            })}

            {/* Notes */}
            {NOTES.map((nt, i) => {
              const rowIdx = TOP_NOTE - nt.note;
              if (rowIdx < 0 || rowIdx >= ROW_COUNT) return null;
              const x = tickToPx(nt.tick);
              const w = tickToPx(nt.len);
              const y = rowIdx * rowH;
              const brightness = 0.5 + (nt.vel / 127) * 0.5;
              return (
                <div key={i} className="pr-note" style={{
                  position: "absolute", left: x, top: y + 2,
                  width: w - 2, height: rowH - 4,
                  background: `rgba(199, 245, 70, ${brightness})`,
                  borderLeft: "2px solid var(--lime)",
                  borderRadius: 2,
                  boxShadow: "0 0 12px rgba(199,245,70,0.18)",
                }}>
                  <span style={{
                    fontFamily: "var(--f-mono)",
                    fontSize: 9,
                    color: "rgba(0,0,0,0.7)",
                    padding: "2px 4px",
                    fontWeight: 600,
                    letterSpacing: 0,
                  }}>
                    {noteLabel(nt.note)}
                  </span>
                </div>
              );
            })}

            {/* Playhead */}
            <div style={{
              position: "absolute", left: tickToPx(PLAYHEAD_TICK), top: 0, bottom: 0,
              width: 1, background: "var(--lime)", boxShadow: "0 0 10px var(--lime)",
              pointerEvents: "none",
            }}/>
          </div>
        </div>

        {/* Velocity strip */}
        <div className="pr-vel-strip">
          <div style={{ width: keyW, padding: "0 12px", fontFamily: "var(--f-mono)", fontSize: 9, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--t2)", display: "flex", alignItems: "center" }}>
            VELOCITY
          </div>
          <div style={{ flex: 1, position: "relative", height: "100%" }}>
            {NOTES.map((nt, i) => {
              const x = tickToPx(nt.tick);
              const h = (nt.vel / 127) * 50;
              return (
                <div key={i} style={{
                  position: "absolute", left: x, bottom: 4,
                  width: 4, height: h,
                  background: "var(--lime)",
                  opacity: 0.7,
                }}/>
              );
            })}
            <div style={{ position: "absolute", left: tickToPx(PLAYHEAD_TICK), top: 0, bottom: 0, width: 1, background: "var(--lime)", opacity: 0.4 }}/>
          </div>
        </div>
      </div>

      {/* Bottom toolbar — quick synth params */}
      <div className="pr-bottom">
        <div className="pr-params">
          <Knob label="CUTOFF" value="2.4 kHz" deg={20} color="cyan" size="sm" />
          <Knob label="RESO"   value="0.62" deg={-30} color="cyan" size="sm" />
          <Knob label="DRIVE"  value="0.28" deg={-90} color="cyan" size="sm" />
          <Knob label="ATTACK" value="4 ms"  deg={-110} color="cyan" size="sm"/>
          <Knob label="DECAY"  value="120ms" deg={-40} color="cyan" size="sm"/>
          <Knob label="SUSTAIN"value="0.55"  deg={0}   color="cyan" size="sm"/>
          <Knob label="RELEASE"value="380ms" deg={30}  color="cyan" size="sm"/>
        </div>
        <div style={{ flex: 1 }} />
        <div className="pr-bottom-actions">
          <button className="btn"><Icon name="loop" size={11}/> ARP</button>
          <button className="btn"><Icon name="fx" size={11}/> FX</button>
          <button className="btn">SYNTH PARAMS</button>
        </div>
      </div>

      <style>{`
        .pr-area { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
        .pr-bar-header { display: flex; align-items: stretch; background: var(--bg-2); border-bottom: 1px solid var(--line-2); }

        .pr-key {
          display: flex;
          align-items: center;
          padding: 0 10px;
          font-family: var(--f-mono);
          font-size: 10px;
          letter-spacing: 0.05em;
          border-bottom: 1px solid var(--line);
        }
        .pr-key.white { background: var(--bg-2); color: var(--t1); }
        .pr-key.black { background: var(--bg-1); color: var(--t2); }

        .pr-vel-strip {
          height: 64px;
          background: var(--bg-2);
          border-top: 1px solid var(--line-2);
          display: flex;
        }

        .pr-bottom {
          height: 100px;
          background: var(--bg-2);
          border-top: 1px solid var(--line-2);
          display: flex;
          align-items: center;
          padding: 0 16px;
        }
        .pr-params {
          display: flex;
          gap: 18px;
          align-items: center;
        }
        .pr-bottom-actions {
          display: flex;
          gap: 8px;
          align-items: center;
        }
      `}</style>
    </div>
  );
};

window.PianoRollEditor = PianoRollEditor;
