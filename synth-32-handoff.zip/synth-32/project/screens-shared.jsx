/* global React */
/*  Shared building blocks for synth-32 screens.
 *  All components exposed on window for cross-file use under Babel.
 */

const { useState } = React;

// ---------- Icons (tiny, inline SVG so we never hand-draw chrome) ----------

const Icon = ({ name, size = 16, color = "currentColor" }) => {
  const s = { width: size, height: size, color };
  const stroke = { fill: "none", stroke: "currentColor", strokeWidth: 1.6, strokeLinecap: "round", strokeLinejoin: "round" };
  switch (name) {
    case "play":    return <svg viewBox="0 0 16 16" style={s}><polygon points="4,3 13,8 4,13" fill="currentColor"/></svg>;
    case "stop":    return <svg viewBox="0 0 16 16" style={s}><rect x="4" y="4" width="8" height="8" fill="currentColor"/></svg>;
    case "rec":     return <svg viewBox="0 0 16 16" style={s}><circle cx="8" cy="8" r="4.5" fill="currentColor"/></svg>;
    case "back":    return <svg viewBox="0 0 16 16" style={s}><path d="M10 3 L4 8 L10 13" {...stroke}/></svg>;
    case "menu":    return <svg viewBox="0 0 16 16" style={s}><path d="M2 4h12 M2 8h12 M2 12h12" {...stroke}/></svg>;
    case "plus":    return <svg viewBox="0 0 16 16" style={s}><path d="M8 3v10 M3 8h10" {...stroke}/></svg>;
    case "minus":   return <svg viewBox="0 0 16 16" style={s}><path d="M3 8h10" {...stroke}/></svg>;
    case "x":       return <svg viewBox="0 0 16 16" style={s}><path d="M3 3l10 10 M13 3L3 13" {...stroke}/></svg>;
    case "chev-d":  return <svg viewBox="0 0 16 16" style={s}><path d="M3 6l5 5 5-5" {...stroke}/></svg>;
    case "chev-r":  return <svg viewBox="0 0 16 16" style={s}><path d="M6 3l5 5-5 5" {...stroke}/></svg>;
    case "chev-l":  return <svg viewBox="0 0 16 16" style={s}><path d="M10 3L5 8l5 5" {...stroke}/></svg>;
    case "drag":    return <svg viewBox="0 0 16 16" style={s}><circle cx="6" cy="4" r="1" fill="currentColor"/><circle cx="10" cy="4" r="1" fill="currentColor"/><circle cx="6" cy="8" r="1" fill="currentColor"/><circle cx="10" cy="8" r="1" fill="currentColor"/><circle cx="6" cy="12" r="1" fill="currentColor"/><circle cx="10" cy="12" r="1" fill="currentColor"/></svg>;
    case "fx":      return <svg viewBox="0 0 16 16" style={s}><path d="M2 8 Q5 2 8 8 T14 8" {...stroke}/></svg>;
    case "wifi":    return <svg viewBox="0 0 16 16" style={s}><path d="M2 6 Q8 0 14 6 M4 9 Q8 5 12 9 M6 12 Q8 10 10 12" {...stroke}/><circle cx="8" cy="13.5" r="0.8" fill="currentColor"/></svg>;
    case "sd":      return <svg viewBox="0 0 16 16" style={s}><path d="M4 2 H11 L14 5 V14 H4 Z" {...stroke}/><path d="M7 2 V4 M9 2 V4 M11 2 V4" {...stroke}/></svg>;
    case "wave":    return <svg viewBox="0 0 16 16" style={s}><path d="M1 8 L3 4 L5 12 L7 5 L9 11 L11 6 L13 10 L15 8" {...stroke}/></svg>;
    case "mute":    return <svg viewBox="0 0 16 16" style={s}><rect x="3" y="3" width="10" height="10" fill="currentColor"/></svg>;
    case "unmute":  return <svg viewBox="0 0 16 16" style={s}><rect x="3" y="3" width="10" height="10" {...stroke}/></svg>;
    case "loop":    return <svg viewBox="0 0 16 16" style={s}><path d="M3 9 V11 H7 M3 11 L5 13 M13 7 V5 H9 M13 5 L11 3" {...stroke}/></svg>;
    case "solo":    return <svg viewBox="0 0 16 16" style={s}><text x="8" y="11.5" textAnchor="middle" fontSize="9" fontFamily="monospace" fill="currentColor" fontWeight="700">S</text></svg>;
    case "trash":   return <svg viewBox="0 0 16 16" style={s}><path d="M3 4h10 M5 4 V3 a1 1 0 0 1 1 -1 h4 a1 1 0 0 1 1 1 v1 M5 4 v9 a1 1 0 0 0 1 1 h4 a1 1 0 0 0 1 -1 v-9" {...stroke}/></svg>;
    default: return null;
  }
};
window.Icon = Icon;

// ---------- TopBar variants ----------

const SongTopBar = ({ bpm = 120.0, playing = true, song = "Pearl.s32", dirty = false, live = false }) => (
  <div className="topbar">
    <div className="topbar-cell brand" style={{ width: 168 }}>
      <span style={{ fontSize: 11, letterSpacing: "0.22em" }}>SYNTH</span>
      <span style={{ color: "var(--lime)", fontSize: 11, letterSpacing: "0.22em" }}>—32</span>
    </div>
    <div className="topbar-cell" style={{ gap: 14 }}>
      <span className="tiny">BPM</span>
      <span className="big">{bpm.toFixed(1)}</span>
    </div>
    <div className="topbar-cell" style={{ gap: 10, padding: "0 12px" }}>
      <button className={`btn icon ${playing ? "primary" : ""}`} style={{ height: 36, width: 36 }}>
        <Icon name="play" size={14} />
      </button>
      <button className="btn icon" style={{ height: 36, width: 36 }}>
        <Icon name="stop" size={12} />
      </button>
    </div>
    <div className="topbar-cell spacer" style={{ gap: 10 }}>
      <Icon name="sd" size={14} />
      <span className="num" style={{ fontSize: 13, color: "var(--t0)", textTransform: "none", letterSpacing: 0 }}>
        {song}{dirty ? " *" : ""}
      </span>
    </div>
    <div className={`topbar-cell ${live ? "active" : ""}`}>LIVE</div>
    <div className="topbar-cell">MASTER</div>
    <div className="topbar-mini-cell">
      <Icon name="menu" size={16} />
    </div>
  </div>
);

const MiniTopBar = ({ title, right }) => (
  <div className="topbar">
    <div className="topbar-mini-cell">
      <Icon name="back" size={16} />
    </div>
    <div className="topbar-cell" style={{ width: 200, fontSize: 13, color: "var(--t0)", textTransform: "none", letterSpacing: "0.04em" }}>
      {title}
    </div>
    <div className="topbar-cell spacer" />
    {right}
  </div>
);

window.SongTopBar = SongTopBar;
window.MiniTopBar = MiniTopBar;

// ---------- Dropdown stub (visual only) ----------
const Drop = ({ label, value, w = 110 }) => (
  <div className="topbar-cell" style={{ borderLeft: "1px solid var(--line)", borderRight: "1px solid var(--line)", width: w, padding: "0 12px", gap: 8 }}>
    {label && <span className="tiny">{label}</span>}
    <span style={{ color: "var(--t0)", fontFamily: "var(--f-mono)", fontSize: 12, textTransform: "none", letterSpacing: 0 }}>{value}</span>
    <span style={{ marginLeft: "auto", color: "var(--t2)" }}><Icon name="chev-d" size={12} /></span>
  </div>
);
window.Drop = Drop;

// ---------- Knob with label / value ----------
const Knob = ({ label, value, deg = -60, color = "lime", size = "md" }) => (
  <div className="knob-cell">
    <div className={`knob ${color === "amber" ? "amber" : color === "cyan" ? "cyan" : ""} ${size === "sm" ? "sm" : ""}`} style={{ "--knob-deg": `${deg}deg` }} />
    <div className="label">{label}</div>
    <div className="val">{value}</div>
  </div>
);
window.Knob = Knob;

// ---------- Pan indicator (compact) ----------
const Pan = ({ v = 0 }) => {
  // v in [-1, 1]
  const ticks = 11;
  const pos = Math.round((v + 1) / 2 * (ticks - 1));
  return (
    <div style={{ display: "flex", gap: 2, alignItems: "center" }}>
      {Array.from({ length: ticks }).map((_, i) => {
        const center = i === Math.floor(ticks / 2);
        const on = i === pos;
        return (
          <div key={i} style={{
            width: 3,
            height: center ? 10 : (i === 0 || i === ticks - 1 ? 8 : 6),
            background: on ? "var(--lime)" : (center ? "var(--line-3)" : "var(--bg-4)"),
            borderRadius: 1,
          }} />
        );
      })}
    </div>
  );
};
window.Pan = Pan;

// ---------- Lane type chip ----------
const TypeChip = ({ type }) => {
  if (type === "drum")  return <span className="chip drum">DRUM</span>;
  if (type === "synth") return <span className="chip synth">SYNTH</span>;
  if (type === "wav")   return <span className="chip wav">WAV</span>;
  return <span className="chip">—</span>;
};
window.TypeChip = TypeChip;

// ---------- Empty-state SVG striped placeholder (use sparingly) ----------
const Stripe = ({ w, h, label }) => (
  <div style={{
    width: w, height: h,
    background: "repeating-linear-gradient(135deg, #15151A 0 8px, #1A1A20 8px 16px)",
    color: "var(--t2)",
    fontFamily: "var(--f-mono)",
    fontSize: 10,
    letterSpacing: "0.1em",
    textTransform: "uppercase",
    display: "flex", alignItems: "center", justifyContent: "center",
    border: "1px solid var(--line)",
  }}>{label}</div>
);
window.Stripe = Stripe;
