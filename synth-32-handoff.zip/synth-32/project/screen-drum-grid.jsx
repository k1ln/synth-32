/* global React, MiniTopBar, Drop, Icon */

// ===================================================================
//   DRUM GRID EDITOR
// ===================================================================

// Pattern data — 10 rows × 16 steps. v=velocity 0..127, a=accent
const PAT = [
  { name: "KICK",   sample: "Pearl-22-Kick-1.wav",   vol: 0.95, mode: "ONE", steps: [100,0,0,0,  90,0,0,0,  100,0,0,0,  100,0,0,0], col: "lime" },
  { name: "SNARE",  sample: "Pearl-14-Snare-1.wav",  vol: 0.85, mode: "ONE", steps: [0,0,0,0,    110,0,0,30, 0,0,0,40,   110,0,0,0], col: "lime", accent: [4,12] },
  { name: "HH-CL",  sample: "Pearl-Hat-Cl-2.wav",    vol: 0.55, mode: "ONE", steps: [80,0,90,0,  80,0,90,0,  80,0,90,0,  80,0,90,0], col: "lime" },
  { name: "HH-OP",  sample: "Pearl-Hat-Op-1.wav",    vol: 0.6,  mode: "LOOP",steps: [0,0,0,0,    0,0,100,0,  0,0,0,0,    0,0,100,0], col: "amber" },
  { name: "CLAP",   sample: "Linn-Clap-A.wav",       vol: 0.65, mode: "ONE", steps: [0,0,0,0,    100,0,0,0,  0,0,0,0,    100,0,0,0], col: "lime", accent: [4,12] },
  { name: "TOM-H",  sample: "Pearl-Tom-Hi.wav",      vol: 0.7,  mode: "ONE", steps: [0,0,0,0,    0,0,0,0,    0,0,100,0,  0,0,0,0],   col: "lime" },
  { name: "TOM-L",  sample: "Pearl-Tom-Lo.wav",      vol: 0.7,  mode: "ONE", steps: [0,0,0,0,    0,0,0,0,    0,0,0,0,    0,90,0,0], col: "lime" },
  { name: "RIDE",   sample: "Pearl-Ride-1.wav",      vol: 0.5,  mode: "GATE",steps: [0,80,0,80,  0,80,0,80,  0,80,0,80,  0,80,0,80], col: "cyan" },
  { name: "CRASH",  sample: "Pearl-Crash-1.wav",     vol: 0.7,  mode: "ONE", steps: [120,0,0,0,  0,0,0,0,    0,0,0,0,    0,0,0,0],   col: "lime", accent: [0] },
  { name: "PERC",   sample: "808-Conga-Hi.wav",      vol: 0.55, mode: "SLICE",steps:[0,0,90,0,   0,0,90,0,   0,0,90,0,   0,0,90,0],  col: "amber", mute: true },
];

const PLAYHEAD = 5;

const Step = ({ v = 0, accent, isPlay, col = "lime" }) => {
  const accentColor = "var(--amber)";
  const onColor = col === "amber" ? "var(--amber)" : col === "cyan" ? "var(--cyan)" : "var(--lime)";
  let bg = "var(--bg-3)";
  let border = "var(--line-2)";
  let fg = null;
  if (v > 0) {
    bg = accent ? accentColor : onColor;
    border = accent ? accentColor : onColor;
    const opacity = 0.4 + (v / 127) * 0.6;
    fg = (
      <div style={{
        position: "absolute", inset: 0,
        background: accent ? accentColor : onColor,
        opacity,
      }} />
    );
  }
  return (
    <div className={`step ${isPlay ? "play" : ""}`} style={{ background: bg, borderColor: border }}>
      {fg}
      {isPlay && <div className="step-playhead" />}
    </div>
  );
};

const StepGroup = ({ steps, accent = [], playStep, col }) => (
  <div className="step-group">
    {steps.map((v, i) => (
      <Step key={i} v={v} accent={accent.includes(i)} isPlay={i === playStep} col={col} />
    ))}
  </div>
);

const DrumGridEditor = () => (
  <div className="frame">
    <MiniTopBar
      title="Drums · Lane 01"
      right={
        <>
          <Drop label="STEPS" value="16" w={110} />
          <Drop label="BARS"  value="2"  w={100} />
          <Drop label="RES"   value="1/16" w={110} />
        </>
      }
    />

    {/* Bar/beat header */}
    <div className="bar-strip">
      <div style={{ width: 240, padding: "0 16px", display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--t2)", letterSpacing: "0.18em" }}>PLAYHEAD</span>
        <span className="num" style={{ color: "var(--lime)", fontSize: 12 }}>1 · 02 · 03</span>
      </div>
      <div className="bar-grid">
        {Array.from({ length: 4 }).map((_, beat) => (
          <div key={beat} className="bar-beat">
            <span className="bar-num">{beat + 1}</span>
            <span className="bar-tick" />
            <span className="bar-tick" />
            <span className="bar-tick" />
          </div>
        ))}
      </div>
    </div>

    {/* Rows */}
    <div className="rows">
      {PAT.map((row, ri) => (
        <div key={ri} className={`drum-row ${row.mute ? "muted" : ""}`}>
          <div className="row-label">
            <span className="drag-handle"><Icon name="drag" size={10} /></span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{ fontFamily: "var(--f-mono)", fontSize: 12, color: "var(--t0)", fontWeight: 600 }}>{row.name}</span>
                <span style={{ fontFamily: "var(--f-mono)", fontSize: 8, color: row.col === "amber" ? "var(--amber)" : row.col === "cyan" ? "var(--cyan)" : "var(--t2)", letterSpacing: "0.12em" }}>{row.mode}</span>
              </div>
              <div style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--t3)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {row.sample}
              </div>
            </div>
          </div>

          <div className="row-vol">
            <div className="fader" style={{ width: 50 }}>
              <div className="fader-fill" style={{ width: `${row.vol*100}%`, background: row.col === "amber" ? "var(--amber)" : row.col === "cyan" ? "var(--cyan)" : "var(--lime)" }} />
            </div>
          </div>

          <div className="row-ctrls">
            <button className={`mini-btn ${row.mute ? "on-red" : ""}`}>M</button>
            <button className="mini-btn">S</button>
          </div>

          <div className="row-steps">
            {[0,1,2,3].map(g => (
              <StepGroup
                key={g}
                steps={row.steps.slice(g*4, g*4+4)}
                accent={(row.accent || []).filter(a => a >= g*4 && a < g*4+4).map(a => a - g*4)}
                playStep={Math.floor(PLAYHEAD / 4) === g ? PLAYHEAD % 4 : -1}
                col={row.col}
              />
            ))}
          </div>
        </div>
      ))}

      <div className="drum-row add-row">
        <div className="row-label" style={{ color: "var(--t3)" }}>
          <button className="btn" style={{ height: 28, fontSize: 10 }}>
            <Icon name="plus" size={10}/> ADD ROW
          </button>
        </div>
        <div style={{ flex: 1 }} />
      </div>
    </div>

    {/* Bottom toolbar */}
    <div className="bottom-bar">
      <button className="btn"><Icon name="plus" size={11}/> COPY</button>
      <button className="btn">PASTE</button>
      <button className="btn"><Icon name="trash" size={11}/> CLEAR</button>
      <div className="bb-divider"/>
      <div className="bb-group">
        <span className="bb-label">ACCENT</span>
        <div className="fader" style={{ width: 80 }}><div className="fader-fill amber" style={{ width: "60%" }}/></div>
        <span className="num" style={{ fontSize: 11 }}>1.5×</span>
      </div>
      <div className="bb-divider"/>
      <div className="bb-group">
        <span className="bb-label">SWING</span>
        <div className="fader" style={{ width: 80 }}><div className="fader-fill" style={{ width: "50%" }}/></div>
        <span className="num" style={{ fontSize: 11 }}>50%</span>
      </div>
      <div style={{ flex: 1 }}/>
      <button className="btn"><Icon name="fx" size={11}/> FX</button>
      <button className="btn">ADSR</button>
    </div>

    <style>{`
      .bar-strip {
        height: 32px;
        display: flex;
        align-items: center;
        background: var(--bg-2);
        border-bottom: 1px solid var(--line);
        padding: 0;
      }
      .bar-grid {
        flex: 1;
        display: flex;
        padding-right: 16px;
      }
      .bar-beat {
        flex: 1;
        display: flex;
        align-items: center;
        border-left: 1px solid var(--line-2);
        height: 100%;
      }
      .bar-num {
        font-family: var(--f-mono);
        font-size: 11px;
        color: var(--t1);
        padding: 0 8px;
        font-weight: 600;
      }
      .bar-tick {
        flex: 1;
        height: 4px;
        margin-right: 2px;
        background: transparent;
        border-left: 1px solid var(--line);
      }

      .rows {
        flex: 1;
        overflow: hidden;
        background: var(--bg-1);
      }
      .drum-row {
        display: flex;
        align-items: stretch;
        height: 50px;
        border-bottom: 1px solid var(--line);
      }
      .drum-row.muted { opacity: 0.4; }
      .drum-row.add-row { background: var(--bg-2); height: 36px; }
      .drum-row.add-row .row-label { padding: 0 16px; align-items: center; }

      .row-label {
        width: 180px;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 0 12px;
        border-right: 1px solid var(--line);
      }
      .drag-handle { color: var(--t3); cursor: grab; }

      .row-vol {
        width: 70px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-right: 1px solid var(--line);
      }

      .row-ctrls {
        width: 60px;
        display: flex;
        align-items: center;
        gap: 4px;
        padding: 0 6px;
        border-right: 1px solid var(--line);
      }
      .mini-btn {
        width: 22px; height: 22px;
        background: var(--bg-3);
        border: 1px solid var(--line-2);
        color: var(--t2);
        font-family: var(--f-mono);
        font-size: 10px;
        font-weight: 700;
        cursor: pointer;
        border-radius: 2px;
      }
      .mini-btn.on-red { background: var(--red); color: white; border-color: var(--red); }

      .row-steps {
        flex: 1;
        display: flex;
        gap: 8px;
        padding: 6px 12px;
        align-items: center;
      }
      .step-group {
        flex: 1;
        display: flex;
        gap: 4px;
      }
      .step {
        flex: 1;
        height: 36px;
        background: var(--bg-3);
        border: 1px solid var(--line-2);
        border-radius: 2px;
        position: relative;
        overflow: hidden;
      }
      .step.play::after {
        content: "";
        position: absolute;
        inset: 0;
        border: 1px solid var(--t0);
        border-radius: 2px;
        pointer-events: none;
      }
      .step-playhead {
        position: absolute;
        inset: 0;
        background: rgba(255,255,255,0.18);
        mix-blend-mode: screen;
      }

      .bottom-bar {
        height: 56px;
        background: var(--bg-2);
        border-top: 1px solid var(--line-2);
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 0 16px;
      }
      .bb-divider { width: 1px; height: 24px; background: var(--line-2); margin: 0 6px; }
      .bb-group { display: flex; align-items: center; gap: 10px; }
      .bb-label {
        font-family: var(--f-mono);
        font-size: 9px;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        color: var(--t2);
      }
    `}</style>
  </div>
);

window.DrumGridEditor = DrumGridEditor;
