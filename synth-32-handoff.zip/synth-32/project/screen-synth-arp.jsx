/* global React, MiniTopBar, Icon, Knob, Drop */

// ===================================================================
//   SYNTH PICKER + ARP EDITOR
// ===================================================================

const SYNTH_TYPES = [
  { id: 0,  cat: "WAVE",  name: "Mono Wavetable",     hint: "1 osc · ADSR",          voices: "1",  selected: false },
  { id: 1,  cat: "WAVE",  name: "Poly Wavetable",     hint: "5-voice polyphonic",     voices: "5"  },
  { id: 2,  cat: "WAVE",  name: "Super Saw",          hint: "7 detuned saws",          voices: "5"  },
  { id: 17, cat: "WAVE",  name: "Wavetable Morph",    hint: "4-point morph",           voices: "5"  },
  { id: 19, cat: "WAVE",  name: "Bit-Crush Synth",    hint: "Wavetable + crush",       voices: "5"  },

  { id: 3,  cat: "FM",    name: "FM 2-OP",            hint: "Carrier + mod",           voices: "5"  },
  { id: 4,  cat: "FM",    name: "FM 4-OP",            hint: "DX7-style · 8 algos",     voices: "5"  },

  { id: 5,  cat: "SUB",   name: "Subtractive",        hint: "Saw → reso filter",       voices: "1", selected: true },
  { id: 10, cat: "SUB",   name: "Bass Synth",         hint: "Mono · drive · porta",    voices: "1"  },
  { id: 11, cat: "SUB",   name: "Lead Synth",         hint: "PWM · vibrato",           voices: "1"  },

  { id: 6,  cat: "PHYS",  name: "Plucked String (KS)",hint: "Karplus-Strong",          voices: "5"  },
  { id: 7,  cat: "PHYS",  name: "Bell · Modal",       hint: "8 partials · damping",    voices: "5"  },
  { id: 18, cat: "PHYS",  name: "Vowel · Formant",    hint: "3 BP filter cascade",     voices: "5"  },

  { id: 8,  cat: "ADD",   name: "Pad · Additive",     hint: "16 sine partials",        voices: "5"  },
  { id: 16, cat: "ADD",   name: "Organ · Drawbar",    hint: "9 drawbars · rotary",     voices: "5"  },
  { id: 12, cat: "ADD",   name: "Chord Synth",        hint: "Stacked intervals",       voices: "5"  },

  { id: 9,  cat: "DRUM",  name: "Noise Synth",        hint: "Band-lim noise + VCF",    voices: "1"  },
  { id: 13, cat: "DRUM",  name: "Drum BD",            hint: "Sine + pitch env + click",voices: "1"  },
  { id: 14, cat: "DRUM",  name: "Drum SD",            hint: "Tone + noise + BP",       voices: "1"  },
  { id: 15, cat: "DRUM",  name: "Drum HH",            hint: "6 metal osc + HP",        voices: "1"  },
];

const SynthPicker = () => (
  <div className="frame">
    <MiniTopBar
      title="Synth · Lane 02 · Bass"
      right={
        <button className="topbar-cell action" style={{ background: "var(--lime)", color: "#0A0A0A", border: "none", padding: "0 18px", fontWeight: 600, cursor: "pointer" }}>
          USE SUBTRACTIVE
        </button>
      }
    />

    <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
      {/* Category sidebar */}
      <div style={{ width: 160, background: "var(--bg-2)", borderRight: "1px solid var(--line)" }}>
        <div className="section-head">CATEGORY</div>
        {[
          { c: "ALL",   n: 20, sel: false },
          { c: "WAVE",  n: 5,  sel: false },
          { c: "FM",    n: 2,  sel: false },
          { c: "SUB",   n: 3,  sel: true },
          { c: "PHYS",  n: 3,  sel: false },
          { c: "ADD",   n: 3,  sel: false },
          { c: "DRUM",  n: 4,  sel: false },
        ].map((cat, i) => (
          <div key={i} className="sp-cat" style={{
            background: cat.sel ? "var(--lime-dim)" : "transparent",
            borderLeft: cat.sel ? "2px solid var(--lime)" : "2px solid transparent",
          }}>
            <span style={{ color: cat.sel ? "var(--lime)" : "var(--t0)" }}>{cat.c}</span>
            <span className="num" style={{ color: "var(--t2)" }}>{cat.n}</span>
          </div>
        ))}
      </div>

      {/* Synth grid */}
      <div style={{ flex: 1, padding: 16, overflow: "hidden", display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--t2)" }}>SUBTRACTIVE · 3 SYNTHS</span>
          <div style={{ flex: 1 }}/>
          <Drop label="SORT" value="Category" w={150} />
        </div>

        <div className="sp-grid">
          {SYNTH_TYPES.map((s) => (
            <div key={s.id} className={`sp-card ${s.selected ? "sel" : ""}`}>
              <div className="sp-card-row1">
                <span className="sp-id">{String(s.id).padStart(2,"0")}</span>
                <span className="sp-cat-tag">{s.cat}</span>
                <span className="sp-voices">{s.voices}v</span>
              </div>
              <div className="sp-name">{s.name}</div>
              <div className="sp-hint">{s.hint}</div>
              {/* Mini waveform preview */}
              <svg viewBox="0 0 100 24" preserveAspectRatio="none" style={{ width: "100%", height: 24, marginTop: 4 }}>
                <path
                  d={s.cat === "FM"   ? "M 0 12 Q 5 4 10 12 T 20 12 T 30 12 T 40 12 T 50 12 T 60 12 T 70 12 T 80 12 T 90 12 T 100 12" :
                     s.cat === "WAVE" ? "M 0 4 L 12 4 L 12 20 L 24 20 L 24 4 L 36 4 L 36 20 L 48 20 L 48 4 L 60 4 L 60 20 L 72 20 L 72 4 L 84 4 L 84 20 L 96 20" :
                     s.cat === "PHYS" ? "M 0 12 L 4 4 L 8 18 L 12 8 L 16 14 L 20 10 L 24 13 L 28 11 L 32 12 L 36 12 L 100 12" :
                     s.cat === "ADD" ? "M 0 12 Q 25 -2 50 12 T 100 12" :
                     s.cat === "DRUM"? "M 0 12 L 5 2 L 10 22 L 15 8 L 20 16 L 25 12 L 30 14 L 35 13 L 40 12 L 100 12" :
                     "M 0 16 L 20 16 L 20 8 L 40 8 L 40 16 L 60 16 L 60 8 L 80 8 L 80 16 L 100 16"}
                  stroke={s.selected ? "var(--lime)" : "var(--cyan)"}
                  strokeWidth="1.2"
                  fill="none"
                  opacity="0.8"
                />
              </svg>
            </div>
          ))}
        </div>
      </div>
    </div>

    <style>{`
      .sp-cat {
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 40px;
        padding: 0 16px;
        font-family: var(--f-mono);
        font-size: 12px;
        letter-spacing: 0.08em;
        cursor: pointer;
        border-bottom: 1px solid var(--line);
      }
      .sp-grid {
        flex: 1;
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 8px;
        overflow: hidden;
        align-content: start;
      }
      .sp-card {
        background: var(--bg-2);
        border: 1px solid var(--line-2);
        border-radius: 4px;
        padding: 10px;
        cursor: pointer;
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .sp-card:hover { background: var(--bg-3); border-color: var(--line-3); }
      .sp-card.sel {
        background: var(--lime-dim);
        border-color: var(--lime);
        box-shadow: 0 0 0 1px var(--lime), 0 0 18px var(--lime-glow);
      }
      .sp-card-row1 {
        display: flex; align-items: center; gap: 6px; margin-bottom: 6px;
      }
      .sp-id {
        font-family: var(--f-mono);
        font-size: 9px;
        color: var(--t3);
        background: var(--bg-3);
        padding: 1px 4px;
        border-radius: 2px;
      }
      .sp-card.sel .sp-id { color: var(--lime); }
      .sp-cat-tag {
        font-family: var(--f-mono);
        font-size: 8px;
        letter-spacing: 0.15em;
        color: var(--cyan);
      }
      .sp-card.sel .sp-cat-tag { color: var(--lime); }
      .sp-voices {
        margin-left: auto;
        font-family: var(--f-mono);
        font-size: 9px;
        color: var(--t3);
      }
      .sp-name {
        font-family: var(--f-mono);
        font-size: 12px;
        color: var(--t0);
        font-weight: 600;
        letter-spacing: 0.02em;
      }
      .sp-card.sel .sp-name { color: var(--lime); }
      .sp-hint {
        font-family: var(--f-mono);
        font-size: 9px;
        color: var(--t2);
      }
    `}</style>
  </div>
);

window.SynthPicker = SynthPicker;


// ---------- ARP EDITOR ----------

const ArpEditor = () => {
  const ARP_SEQ = [
    { n: "C2", on: false }, { n: "E2", on: false }, { n: "G2", on: true },
    { n: "C3", on: false }, { n: "E3", on: false }, { n: "G3", on: false },
    { n: "C2", on: false }, { n: "E2", on: false },
  ];

  return (
    <div className="frame">
      <MiniTopBar
        title="Arpeggiator · Bass · Lane 02"
        right={
          <div className="topbar-cell" style={{ width: 150, gap: 10 }}>
            <span className="bb-label" style={{ color: "var(--lime)", fontFamily: "var(--f-mono)", fontSize: 10 }}>● ENABLED</span>
            <div className="toggle on" style={{ marginLeft: "auto" }}><div className="toggle-knob"/></div>
          </div>
        }
      />

      <div className="arp-grid">

        {/* LEFT: mode + held notes */}
        <div className="arp-panel">
          <div className="section-head">MODE</div>
          <div style={{ padding: "0 16px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
            {[
              { m: "UP",       sel: true },
              { m: "DOWN",     sel: false },
              { m: "UP·DOWN",  sel: false },
              { m: "UP·DN·IN", sel: false },
              { m: "ORDER",    sel: false },
              { m: "RANDOM",   sel: false },
              { m: "CHORD",    sel: false },
              { m: "AS PLAYED",sel: false },
            ].map((x, i) => (
              <button key={i} className={`mode-btn ${x.sel ? "sel" : ""}`}>
                {/* tiny pattern preview */}
                <svg viewBox="0 0 30 12" style={{ width: 30, height: 12 }}>
                  {x.m === "UP" && [9,7,5,3].map((y,j) => <rect key={j} x={j*7+1} y={y} width="3" height="3" fill="currentColor"/>)}
                  {x.m === "DOWN" && [3,5,7,9].map((y,j) => <rect key={j} x={j*7+1} y={y} width="3" height="3" fill="currentColor"/>)}
                  {x.m === "UP·DOWN" && [9,7,5,7].map((y,j) => <rect key={j} x={j*7+1} y={y} width="3" height="3" fill="currentColor"/>)}
                  {x.m === "UP·DN·IN" && [9,7,5,3].map((y,j) => <rect key={j} x={j*4+1} y={y} width="2" height="2" fill="currentColor"/>)}
                  {x.m === "ORDER" && [5,9,3,7].map((y,j) => <rect key={j} x={j*7+1} y={y} width="3" height="3" fill="currentColor"/>)}
                  {x.m === "RANDOM" && [3,9,5,7,4].map((y,j) => <rect key={j} x={j*6+1} y={y} width="2" height="2" fill="currentColor"/>)}
                  {x.m === "CHORD" && [3,6,9].map((y,j) => <rect key={j} x="13" y={y} width="3" height="2" fill="currentColor"/>)}
                  {x.m === "AS PLAYED" && [5,9,3,7].map((y,j) => <rect key={j} x={j*7+1} y={y} width="3" height="3" fill="currentColor"/>)}
                </svg>
                <span>{x.m}</span>
              </button>
            ))}
          </div>

          <div className="section-head" style={{ marginTop: 12 }}>HELD NOTES</div>
          <div style={{ padding: "0 16px", display: "flex", gap: 4, flexWrap: "wrap" }}>
            {["C2", "E2", "G2"].map((n,i) => (
              <span key={i} className="chip" style={{ background: "var(--cyan-dim)", color: "var(--cyan)", border: "none", padding: "0 10px", height: 26 }}>{n}</span>
            ))}
            <span className="chip" style={{ background: "transparent", borderStyle: "dashed", color: "var(--t3)", height: 26 }}>+ HOLD</span>
          </div>

          <div className="section-head" style={{ marginTop: 12 }}>OCTAVE RANGE</div>
          <div style={{ padding: "0 16px" }}>
            <div className="seg">
              {[1,2,3,4].map(v => (
                <div key={v} className={`seg-item ${v === 2 ? "on" : ""}`}>{v}</div>
              ))}
            </div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--t3)", marginTop: 6, letterSpacing: "0.12em" }}>
              SEQUENCE LENGTH: 6 STEPS (3 NOTES × 2 OCT)
            </div>
          </div>
        </div>

        {/* MIDDLE: sequence visualization + params */}
        <div className="arp-panel" style={{ flex: 1 }}>
          <div className="section-head">RESULTING SEQUENCE</div>
          <div className="arp-seq">
            {ARP_SEQ.map((s, i) => (
              <div key={i} className={`arp-step ${s.on ? "on" : ""}`}>
                <span className="arp-step-idx num">{String(i+1).padStart(2,"0")}</span>
                <span className="arp-step-note">{s.n}</span>
                <div className="arp-step-velbar"><div style={{ width: "75%" }}/></div>
              </div>
            ))}
          </div>

          <div className="section-head" style={{ marginTop: 8 }}>TIMING</div>
          <div style={{ padding: "0 16px", display: "flex", gap: 24, alignItems: "flex-end" }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, flex: 1 }}>
              <span className="bb-label">STEP DIVISION</span>
              <div className="seg">
                {["1/4","1/8","1/16","1/32"].map(v => (
                  <div key={v} className={`seg-item ${v === "1/16" ? "on" : ""}`}>{v}</div>
                ))}
              </div>
            </div>
            <Knob label="GATE"   value="70%" deg={20}  />
            <Knob label="SWING"  value="58%" deg={-20} color="amber"/>
          </div>

          <div className="section-head" style={{ marginTop: 12 }}>VELOCITY</div>
          <div style={{ padding: "0 16px", display: "flex", gap: 24, alignItems: "flex-end" }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, flex: 1 }}>
              <span className="bb-label">VELOCITY MODE</span>
              <div className="seg">
                {["ORIGINAL","ACCENT","FIXED"].map(v => (
                  <div key={v} className={`seg-item ${v === "ACCENT" ? "on" : ""}`}>{v}</div>
                ))}
              </div>
            </div>
            <Knob label="ACCENT" value="+12 dB" deg={20} color="amber"/>
            <Knob label="FIXED V" value="100" deg={20}/>
          </div>
        </div>

        {/* RIGHT: latch / retrigger / preview */}
        <div className="arp-panel" style={{ width: 280 }}>
          <div className="section-head">BEHAVIOR</div>
          <div style={{ padding: "0 16px", display: "flex", flexDirection: "column", gap: 12 }}>
            <div className="arp-tog">
              <div>
                <div style={{ fontSize: 13, color: "var(--t0)" }}>LATCH</div>
                <div style={{ fontSize: 10, color: "var(--t2)", fontFamily: "var(--f-mono)" }}>Hold notes after release</div>
              </div>
              <div className="toggle on"><div className="toggle-knob"/></div>
            </div>
            <div className="arp-tog">
              <div>
                <div style={{ fontSize: 13, color: "var(--t0)" }}>RETRIGGER</div>
                <div style={{ fontSize: 10, color: "var(--t2)", fontFamily: "var(--f-mono)" }}>Re-gate ADSR each step</div>
              </div>
              <div className="toggle"><div className="toggle-knob"/></div>
            </div>
            <div className="arp-tog">
              <div>
                <div style={{ fontSize: 13, color: "var(--t0)" }}>SYNC TO CLOCK</div>
                <div style={{ fontSize: 10, color: "var(--t2)", fontFamily: "var(--f-mono)" }}>Quantize start to bar</div>
              </div>
              <div className="toggle on"><div className="toggle-knob"/></div>
            </div>
          </div>

          <div className="section-head" style={{ marginTop: 18 }}>PIANO ROLL INTEGRATION</div>
          <div style={{ padding: "0 16px", fontFamily: "var(--f-sans)", fontSize: 11, lineHeight: 1.55, color: "var(--t1)" }}>
            When arp is on, the piano-roll notes are treated as the held set.
            Disable arp to play them as written.
          </div>

          <div style={{ padding: 16, marginTop: "auto" }}>
            <button className="btn primary lg" style={{ width: "100%", justifyContent: "center" }}>
              <Icon name="play" size={11}/> AUDITION ARP
            </button>
          </div>
        </div>
      </div>

      <style>{`
        .arp-grid {
          flex: 1;
          display: flex;
          gap: 1px;
          background: var(--line);
          overflow: hidden;
        }
        .arp-panel {
          background: var(--bg-1);
          width: 300px;
          display: flex;
          flex-direction: column;
        }
        .mode-btn {
          display: flex;
          align-items: center;
          gap: 8px;
          height: 36px;
          padding: 0 12px;
          background: var(--bg-3);
          border: 1px solid var(--line-2);
          border-radius: 3px;
          color: var(--t1);
          cursor: pointer;
          font-family: var(--f-mono);
          font-size: 10px;
          letter-spacing: 0.1em;
        }
        .mode-btn.sel {
          background: var(--lime-dim);
          border-color: var(--lime);
          color: var(--lime);
        }
        .toggle { width: 44px; height: 22px; background: var(--bg-3); border: 1px solid var(--line-2); border-radius: 11px; position: relative; }
        .toggle.on { background: var(--lime); border-color: var(--lime); }
        .toggle-knob { position: absolute; top: 2px; left: 2px; width: 16px; height: 16px; background: var(--t0); border-radius: 50%; }
        .toggle.on .toggle-knob { left: auto; right: 2px; background: #0A0A0A; }

        .arp-seq {
          display: flex;
          gap: 4px;
          padding: 0 16px;
          margin-bottom: 8px;
        }
        .arp-step {
          flex: 1;
          background: var(--bg-3);
          border: 1px solid var(--line-2);
          border-radius: 3px;
          padding: 10px 6px 6px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
        }
        .arp-step.on {
          background: var(--lime);
          border-color: var(--lime);
          color: #0A0A0A;
          box-shadow: 0 0 16px var(--lime-glow);
        }
        .arp-step-idx { font-size: 9px; color: var(--t3); }
        .arp-step.on .arp-step-idx { color: rgba(0,0,0,0.5); }
        .arp-step-note { font-family: var(--f-mono); font-size: 13px; color: var(--t0); font-weight: 600; }
        .arp-step.on .arp-step-note { color: #0A0A0A; }
        .arp-step-velbar { width: 100%; height: 3px; background: var(--bg-4); border-radius: 1px; }
        .arp-step-velbar > div { height: 100%; background: var(--lime); }
        .arp-step.on .arp-step-velbar { background: rgba(0,0,0,0.2); }
        .arp-step.on .arp-step-velbar > div { background: #0A0A0A; }

        .arp-tog {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 12px;
          background: var(--bg-2);
          border: 1px solid var(--line);
          border-radius: 3px;
        }
        .bb-label { font-family: var(--f-mono); font-size: 9px; letter-spacing: 0.18em; text-transform: uppercase; color: var(--t2); }
      `}</style>
    </div>
  );
};

window.ArpEditor = ArpEditor;
