/* global React, SongTopBar, MiniTopBar, Drop, Icon, Pan, TypeChip */

// ===================================================================
//   SONG VIEW — the home screen
// ===================================================================

const SAMPLE_LANES = [
  { i: 1,  name: "Drums",   type: "drum",  source: "AVL · Pearl × 9",       loop: "2 bars", vol: 0.86, pan:  0.0,  fx: ["COMP","EQ3"],            mute: false, playing: true,  step: 5 },
  { i: 2,  name: "Bass",    type: "synth", source: "Subtractive · Mono",    loop: "4 bars", vol: 0.74, pan:  0.0,  fx: ["DRV","LP","CMP"],        mute: false, playing: true,  step: 11 },
  { i: 3,  name: "Lead",    type: "synth", source: "Super Saw · Poly 5",    loop: "3 bars", vol: 0.62, pan:  0.35, fx: ["CHO","DLY","RVB"],       mute: false, playing: true,  step: 8 },
  { i: 4,  name: "Pad",     type: "synth", source: "Additive · 16 part.",   loop: "8 bars", vol: 0.55, pan: -0.15, fx: ["LP","RVB"],              mute: false, playing: true,  step: 2 },
  { i: 5,  name: "Loop A",  type: "wav",   source: "drumloop_124.wav",      loop: "1 bar",  vol: 0.7,  pan: -0.4,  fx: ["FILT","BIT"],            mute: false, playing: true,  step: 14 },
  { i: 6,  name: "Vox Chop",type: "wav",   source: "vox_grain_aah.wav",     loop: "2 bars", vol: 0.5,  pan:  0.6,  fx: ["RVB","PHA"],             mute: true,  playing: false, step: 0 },
  { i: 7,  name: "FM Keys", type: "synth", source: "FM 4-op · Algo 3",      loop: "4 bars", vol: 0.48, pan:  0.0,  fx: ["TRM","DLY"],             mute: false, playing: true,  step: 7 },
  { i: 8,  name: "Perc",    type: "drum",  source: "808 · Linn · 626",      loop: "2 bars", vol: 0.66, pan:  0.25, fx: ["TS","HP"],               mute: false, playing: true,  step: 5 },
  { i: 9,  name: "Bell",    type: "synth", source: "Modal · 8 partials",    loop: "8 bars", vol: 0.4,  pan:  0.0,  fx: ["RVB"],                   mute: false, playing: true,  step: 1 },
  { i: 10, name: "FX Riser",type: "wav",   source: "riser_sweep.wav",       loop: "16 bars",vol: 0.3,  pan:  0.0,  fx: ["FIL","RVB"],             mute: true,  playing: false, step: 0 },
];

const LaneRow = ({ lane, isAdd, idx }) => {
  if (isAdd) {
    return (
      <div className="lane-row add">
        <div className="lane-col idx">{String(idx).padStart(2,"0")}</div>
        <div className="lane-col name muted">empty</div>
        <div className="lane-col type">
          <button className="btn" style={{ height: 28, fontSize: 10 }}>
            <Icon name="plus" size={10} /> ADD LANE
          </button>
        </div>
        <div className="lane-col loop" />
        <div className="lane-col vol" />
        <div className="lane-col pan" />
        <div className="lane-col fx" />
        <div className="lane-col mu" />
        <div className="lane-col play" />
      </div>
    );
  }

  const accent = lane.type === "drum" ? "var(--lime)" : lane.type === "synth" ? "var(--cyan)" : "var(--amber)";

  return (
    <div className={`lane-row ${lane.mute ? "muted" : ""}`}>
      <div className="lane-col idx">
        <span style={{ width: 3, height: 28, background: accent, marginRight: 8, opacity: lane.mute ? 0.3 : 1 }} />
        {String(lane.i).padStart(2,"0")}
      </div>
      <div className="lane-col name">{lane.name}</div>
      <div className="lane-col type">
        <TypeChip type={lane.type} />
        <span className="lane-source">{lane.source}</span>
      </div>
      <div className="lane-col loop num">{lane.loop}</div>
      <div className="lane-col vol">
        <div className="fader" style={{ width: 110 }}>
          <div className="fader-fill" style={{ width: `${lane.vol * 100}%`, background: accent }} />
        </div>
        <span className="num" style={{ fontSize: 10, color: "var(--t2)", width: 36, textAlign: "right" }}>
          {(20 * Math.log10(lane.vol || 0.001)).toFixed(1)} dB
        </span>
      </div>
      <div className="lane-col pan"><Pan v={lane.pan} /></div>
      <div className="lane-col fx">
        <div className="fx-pills">
          {lane.fx.map((n,i)=>(<span key={i} className="fx-pill">{n}</span>))}
          <span className="fx-pill add"><Icon name="plus" size={9} /></span>
        </div>
      </div>
      <div className="lane-col mu">
        <button className={`mu-btn ${lane.mute ? "on" : ""}`}>
          <Icon name={lane.mute ? "mute" : "unmute"} size={10} />
        </button>
      </div>
      <div className="lane-col play">
        {lane.playing ? (
          <div className="play-ind">
            <div className="play-ind-bar"><div style={{ width: `${(lane.step/16)*100}%` }} /></div>
            <span className="num" style={{ fontSize: 10, color: "var(--t2)" }}>{lane.step}/16</span>
          </div>
        ) : (
          <span style={{ color: "var(--t3)", fontFamily: "var(--f-mono)", fontSize: 10 }}>—</span>
        )}
      </div>
    </div>
  );
};

const SongView = () => (
  <div className="frame">
    <SongTopBar bpm={120.0} song="Pearl.s32" dirty={true} />

    {/* Column headers */}
    <div className="lane-row header">
      <div className="lane-col idx">#</div>
      <div className="lane-col name">Name</div>
      <div className="lane-col type">Type / Source</div>
      <div className="lane-col loop">Loop</div>
      <div className="lane-col vol">Volume</div>
      <div className="lane-col pan">Pan</div>
      <div className="lane-col fx">FX Chain</div>
      <div className="lane-col mu">Mute</div>
      <div className="lane-col play">Playhead</div>
    </div>

    <div style={{ flex: 1, overflow: "hidden", display: "flex" }}>
      <div style={{ flex: 1 }}>
        {SAMPLE_LANES.map((l) => <LaneRow key={l.i} lane={l} />)}
        <LaneRow isAdd idx={11} />
        <LaneRow isAdd idx={12} />
      </div>
      <div style={{ width: 4, padding: "8px 0" }}>
        <div className="scrollbar" style={{ height: "100%" }}>
          <div style={{ top: 0, height: "70%" }} />
        </div>
      </div>
    </div>

    {/* Master strip */}
    <div className="master-strip">
      <div className="ms-cell" style={{ width: 180, gap: 10 }}>
        <span className="tiny">MASTER</span>
        <div className="fader" style={{ flex: 1 }}>
          <div className="fader-fill" style={{ width: "82%" }} />
        </div>
        <span className="num" style={{ fontSize: 11, color: "var(--t0)" }}>-1.6</span>
      </div>
      <div className="ms-cell" style={{ flex: 1, gap: 8 }}>
        <span className="tiny">FX</span>
        <div className="fx-pills">
          <span className="fx-pill master">EQ5</span>
          <span className="fx-pill master">CMP</span>
          <span className="fx-pill master">WIDTH</span>
          <span className="fx-pill master">LIM</span>
          <span className="fx-pill add"><Icon name="plus" size={9} /></span>
          <span className="fx-pill add"><Icon name="plus" size={9} /></span>
        </div>
      </div>
      <div className="ms-cell" style={{ width: 280, gap: 10 }}>
        <div className="meter" style={{ width: "100%" }}>
          <div className="meter-row">
            <span style={{ width: 8 }}>L</span>
            <div className="meter-bar"><div className="meter-fill" style={{ width: "72%" }} /></div>
            <span className="num" style={{ width: 40, textAlign: "right" }}>-2.1</span>
          </div>
          <div className="meter-row">
            <span style={{ width: 8 }}>R</span>
            <div className="meter-bar"><div className="meter-fill" style={{ width: "65%" }} /></div>
            <span className="num" style={{ width: 40, textAlign: "right" }}>-3.4</span>
          </div>
        </div>
      </div>
      <div className="ms-cell" style={{ width: 100, gap: 6 }}>
        <span className="tiny">CPU</span>
        <span className="num" style={{ fontSize: 13, color: "var(--lime)" }}>38%</span>
      </div>
      <div className="ms-cell" style={{ width: 130, gap: 6 }}>
        <Icon name="wifi" size={12} />
        <span className="num" style={{ fontSize: 11, color: "var(--t1)" }}>1 client</span>
      </div>
    </div>

    <style>{`
      .lane-row {
        display: flex;
        align-items: center;
        height: 56px;
        border-bottom: 1px solid var(--line);
        padding: 0;
      }
      .lane-row.header {
        height: 30px;
        background: var(--bg-2);
        border-bottom: 1px solid var(--line-2);
        font-family: var(--f-mono);
        font-size: 9px;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        color: var(--t2);
      }
      .lane-row.add .lane-col.name { color: var(--t3); font-style: italic; }
      .lane-row.muted { opacity: 0.42; }

      .lane-col { display: flex; align-items: center; gap: 8px; padding: 0 12px; height: 100%; border-right: 1px solid var(--line); }
      .lane-col.idx  { width: 64px;  font-family: var(--f-mono); color: var(--t2); }
      .lane-col.name { width: 130px; color: var(--t0); font-weight: 500; }
      .lane-col.type { flex: 1; min-width: 0; }
      .lane-col.loop { width: 76px;  color: var(--t1); }
      .lane-col.vol  { width: 200px; gap: 10px; }
      .lane-col.pan  { width: 80px; }
      .lane-col.fx   { width: 230px; }
      .lane-col.mu   { width: 60px; justify-content: center; }
      .lane-col.play { width: 130px; }

      .lane-source {
        font-family: var(--f-mono);
        font-size: 11px;
        color: var(--t2);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .fx-pills { display: flex; gap: 4px; flex-wrap: nowrap; overflow: hidden; }
      .fx-pill {
        font-family: var(--f-mono);
        font-size: 9px;
        letter-spacing: 0.08em;
        padding: 3px 6px;
        background: var(--bg-3);
        color: var(--t1);
        border-radius: 2px;
        border: 1px solid var(--line-2);
      }
      .fx-pill.add {
        background: transparent;
        color: var(--t3);
        border-style: dashed;
        padding: 3px 5px;
      }
      .fx-pill.master {
        color: var(--lime);
        border-color: var(--lime-dim);
        background: var(--lime-dim);
      }

      .mu-btn {
        width: 32px; height: 32px;
        background: var(--bg-3);
        border: 1px solid var(--line-2);
        border-radius: 2px;
        color: var(--t2);
        display: flex; align-items: center; justify-content: center;
        cursor: pointer;
      }
      .mu-btn.on { background: var(--red); color: white; border-color: var(--red); }

      .play-ind { display: flex; flex-direction: column; gap: 4px; width: 100%; }
      .play-ind-bar { height: 3px; background: var(--bg-4); overflow: hidden; }
      .play-ind-bar > div { height: 100%; background: var(--lime); transition: width 0.1s linear; }

      .master-strip {
        display: flex;
        height: 64px;
        min-height: 64px;
        background: var(--bg-2);
        border-top: 1px solid var(--line-2);
      }
      .ms-cell {
        height: 100%;
        display: flex;
        align-items: center;
        padding: 0 16px;
        border-right: 1px solid var(--line);
      }
      .ms-cell .tiny {
        font-family: var(--f-mono);
        font-size: 9px;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        color: var(--t2);
      }
    `}</style>
  </div>
);

window.SongView = SongView;
