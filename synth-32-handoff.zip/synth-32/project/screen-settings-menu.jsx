/* global React, SongTopBar, MiniTopBar, Icon */

// ===================================================================
//   SETTINGS
// ===================================================================

const SettingRow = ({ label, sub, children }) => (
  <div className="set-row">
    <div className="set-row-label">
      <div className="set-label">{label}</div>
      {sub && <div className="set-sub">{sub}</div>}
    </div>
    <div className="set-row-ctrl">{children}</div>
  </div>
);

const Toggle = ({ on }) => (
  <div className={`toggle ${on ? "on" : ""}`}>
    <div className="toggle-knob"/>
  </div>
);

const SettingsScreen = () => (
  <div className="frame">
    <MiniTopBar
      title="Settings"
      right={
        <div className="topbar-cell" style={{ width: 140, color: "var(--lime)" }}>
          <Icon name="sd" size={12}/>
          <span style={{ fontSize: 11, color: "var(--lime)" }}>SAVED</span>
        </div>
      }
    />

    <div className="set-grid">

      {/* AUDIO */}
      <div className="set-panel">
        <div className="set-panel-head">
          <span className="set-panel-num num">01</span>
          AUDIO
        </div>
        <SettingRow label="Output Volume" sub="Default boot level — applied at startup">
          <div style={{ display: "flex", gap: 12, alignItems: "center", width: 240 }}>
            <div className="fader" style={{ flex: 1 }}><div className="fader-fill" style={{ width: "75%" }}/></div>
            <span className="num" style={{ fontSize: 12, color: "var(--t0)", width: 36, textAlign: "right" }}>75%</span>
          </div>
        </SettingRow>
        <SettingRow label="I2S Buffer Size" sub="Lower = less latency · higher = fewer dropouts">
          <div className="seg" style={{ width: 240 }}>
            {["128","256","512","1024"].map(v => (
              <div key={v} className={`seg-item ${v === "512" ? "on" : ""}`}>{v}</div>
            ))}
          </div>
        </SettingRow>
        <SettingRow label="Sample Rate" sub="Engine native — 48 kHz recommended">
          <div className="seg" style={{ width: 240 }}>
            {["44.1k","48k","88.2k","96k"].map(v => (
              <div key={v} className={`seg-item ${v === "48k" ? "on" : ""}`}>{v}</div>
            ))}
          </div>
        </SettingRow>
        <SettingRow label="Mute when WiFi audio active" sub="Speaker disabled while a phone streams audio">
          <Toggle on />
        </SettingRow>
      </div>

      {/* DEFAULTS */}
      <div className="set-panel">
        <div className="set-panel-head">
          <span className="set-panel-num num">02</span>
          PROJECT DEFAULTS
        </div>
        <SettingRow label="Default BPM" sub="Used when creating a new song">
          <div className="field" style={{ width: 120 }}>
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 14, color: "var(--lime)" }}>120.0</span>
          </div>
        </SettingRow>
        <SettingRow label="Default Loop Length" sub="Bars per lane in new project">
          <div className="seg" style={{ width: 240 }}>
            {["1","2","4","8","16"].map(v => (
              <div key={v} className={`seg-item ${v === "2" ? "on" : ""}`}>{v}</div>
            ))}
          </div>
        </SettingRow>
        <SettingRow label="Default PPQN" sub="Tick resolution per quarter note">
          <div className="seg" style={{ width: 240 }}>
            {["24","48","96","192"].map(v => (
              <div key={v} className={`seg-item ${v === "96" ? "on" : ""}`}>{v}</div>
            ))}
          </div>
        </SettingRow>
        <SettingRow label="Auto-save on screen leave" sub="Write song to SD without prompt">
          <Toggle on />
        </SettingRow>
      </div>

      {/* DISPLAY */}
      <div className="set-panel">
        <div className="set-panel-head">
          <span className="set-panel-num num">03</span>
          DISPLAY
        </div>
        <SettingRow label="Brightness" sub="Backlight intensity">
          <div style={{ display: "flex", gap: 12, alignItems: "center", width: 240 }}>
            <div className="fader" style={{ flex: 1 }}><div className="fader-fill" style={{ width: "80%" }}/></div>
            <span className="num" style={{ fontSize: 12, color: "var(--t0)", width: 36, textAlign: "right" }}>80%</span>
          </div>
        </SettingRow>
        <SettingRow label="Sleep timer" sub="Dim display after inactivity">
          <div className="seg" style={{ width: 240 }}>
            {["OFF","2m","5m","15m"].map(v => (
              <div key={v} className={`seg-item ${v === "5m" ? "on" : ""}`}>{v}</div>
            ))}
          </div>
        </SettingRow>
        <SettingRow label="Show playhead overlay" sub="Vertical line on grid editors">
          <Toggle on />
        </SettingRow>
      </div>

      {/* WIFI */}
      <div className="set-panel">
        <div className="set-panel-head">
          <span className="set-panel-num num">04</span>
          <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <Icon name="wifi" size={12}/>
            WIFI · UPLOAD
            <span className="badge lime" style={{ marginLeft: 6 }}>AP UP</span>
          </span>
        </div>
        <SettingRow label="AP SSID">
          <div className="field" style={{ width: 240 }}>
            <span style={{ color: "var(--t0)" }}>synth-32</span>
          </div>
        </SettingRow>
        <SettingRow label="AP Password" sub="Tap to change">
          <div className="field" style={{ width: 240 }}>
            <span style={{ color: "var(--t2)" }}>● ● ● ● ● ● ● ●</span>
          </div>
        </SettingRow>
        <SettingRow label="Hostnames" sub="Open any of these in a browser after joining the AP">
          <div style={{ display: "flex", flexDirection: "column", gap: 4, alignItems: "flex-end" }}>
            <span className="num" style={{ fontSize: 11, color: "var(--lime)" }}>synth-32.local</span>
            <span className="num" style={{ fontSize: 11, color: "var(--t1)" }}>synth.local · synth32.local</span>
            <span className="num" style={{ fontSize: 11, color: "var(--t2)" }}>192.168.4.1 (fallback)</span>
          </div>
        </SettingRow>
        <SettingRow label="Connected clients">
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <span className="num" style={{ color: "var(--lime)", fontSize: 14 }}>1</span>
            <span className="num" style={{ color: "var(--t2)", fontSize: 10 }}>iPhone-Mark · audio · 1.4 Mbps</span>
          </div>
        </SettingRow>
      </div>

      {/* DEVICE */}
      <div className="set-panel" style={{ gridColumn: "span 2" }}>
        <div className="set-panel-head">
          <span className="set-panel-num num">05</span>
          DEVICE
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", padding: "0 16px 16px", gap: 14 }}>
          <div className="dev-stat">
            <div className="dev-stat-l">FIRMWARE</div>
            <div className="dev-stat-v num">v0.4.2 · 2026-05-26</div>
          </div>
          <div className="dev-stat">
            <div className="dev-stat-l">CHIP</div>
            <div className="dev-stat-v num">ESP32-P4 / C6</div>
          </div>
          <div className="dev-stat">
            <div className="dev-stat-l">PSRAM</div>
            <div className="dev-stat-v num">18.4 / 32 MB</div>
          </div>
          <div className="dev-stat">
            <div className="dev-stat-l">SD CARD</div>
            <div className="dev-stat-v num">437 MB / 32 GB</div>
          </div>
          <div className="dev-stat">
            <div className="dev-stat-l">UPTIME</div>
            <div className="dev-stat-v num">04:21:08</div>
          </div>
          <div className="dev-stat">
            <div className="dev-stat-l">CPU CORE 0</div>
            <div className="dev-stat-v num">12%</div>
          </div>
          <div className="dev-stat">
            <div className="dev-stat-l">CPU CORE 1 (AUDIO)</div>
            <div className="dev-stat-v num" style={{ color: "var(--lime)" }}>38%</div>
          </div>
          <div className="dev-stat">
            <div className="dev-stat-l">DISPLAY FPS</div>
            <div className="dev-stat-v num">60</div>
          </div>
        </div>
      </div>
    </div>

    <style>{`
      .set-grid {
        flex: 1;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1px;
        background: var(--line);
        overflow: hidden;
      }
      .set-panel {
        background: var(--bg-1);
        display: flex;
        flex-direction: column;
      }
      .set-panel-head {
        display: flex;
        align-items: center;
        gap: 12px;
        height: 44px;
        padding: 0 16px;
        font-family: var(--f-mono);
        font-size: 11px;
        letter-spacing: 0.2em;
        text-transform: uppercase;
        color: var(--t0);
        background: var(--bg-2);
        border-bottom: 1px solid var(--line);
      }
      .set-panel-num { color: var(--lime); }

      .set-row {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 12px 16px;
        border-bottom: 1px solid var(--line);
        min-height: 56px;
      }
      .set-row-label { flex: 1; }
      .set-label { font-family: var(--f-sans); font-size: 13px; color: var(--t0); }
      .set-sub { font-family: var(--f-mono); font-size: 10px; color: var(--t2); margin-top: 2px; }

      .toggle {
        width: 44px; height: 24px;
        background: var(--bg-3);
        border-radius: 12px;
        border: 1px solid var(--line-2);
        position: relative;
        cursor: pointer;
      }
      .toggle.on { background: var(--lime); border-color: var(--lime); }
      .toggle-knob {
        position: absolute;
        top: 2px; left: 2px;
        width: 18px; height: 18px;
        background: var(--t0);
        border-radius: 50%;
      }
      .toggle.on .toggle-knob { left: auto; right: 2px; background: #0A0A0A; }

      .dev-stat { display: flex; flex-direction: column; gap: 4px; padding: 10px 12px; background: var(--bg-2); border: 1px solid var(--line); border-radius: 4px; }
      .dev-stat-l { font-family: var(--f-mono); font-size: 9px; letter-spacing: 0.18em; text-transform: uppercase; color: var(--t2); }
      .dev-stat-v { font-family: var(--f-mono); font-size: 13px; color: var(--t0); }
    `}</style>
  </div>
);

window.SettingsScreen = SettingsScreen;


// ===================================================================
//   MAIN MENU OVERLAY (over Song View)
// ===================================================================

const MainMenuOverlay = () => (
  <div className="frame">
    {/* Dimmed song view backdrop */}
    <SongTopBar bpm={120.0} song="Pearl.s32" dirty={true} />
    <div style={{ flex: 1, position: "relative", background: "var(--bg-1)", overflow: "hidden" }}>
      {/* Faint backdrop content (just decorative) */}
      <div style={{ position: "absolute", inset: 0, opacity: 0.15 }}>
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} style={{ display: "flex", height: 56, borderBottom: "1px solid var(--line)" }}>
            <div style={{ width: 64, padding: "0 12px", display: "flex", alignItems: "center", color: "var(--t2)", fontFamily: "var(--f-mono)" }}>0{i+1}</div>
            <div style={{ width: 130, padding: "0 12px", display: "flex", alignItems: "center", color: "var(--t0)" }}>Lane {i+1}</div>
            <div style={{ flex: 1 }}/>
          </div>
        ))}
      </div>

      {/* Dim overlay */}
      <div style={{ position: "absolute", inset: 0, background: "rgba(8,8,10,0.78)" }}/>

      {/* Slide-up menu */}
      <div className="mm-panel">
        <div className="mm-head">
          <div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, letterSpacing: "0.22em", color: "var(--lime)", marginBottom: 4 }}>SYNTH—32</div>
            <div style={{ fontFamily: "var(--f-sans)", fontSize: 22, color: "var(--t0)", fontWeight: 500 }}>Main Menu</div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--t2)", marginTop: 4 }}>
              Pearl.s32 · 10 lanes · unsaved changes
            </div>
          </div>
          <button className="mm-close"><Icon name="x" size={14}/></button>
        </div>

        <div className="mm-grid">
          <div className="mm-card primary">
            <div className="mm-card-num">01</div>
            <div className="mm-card-title">NEW SONG</div>
            <div className="mm-card-sub">Discards unsaved changes</div>
            <Icon name="plus" size={20}/>
          </div>
          <div className="mm-card">
            <div className="mm-card-num">02</div>
            <div className="mm-card-title">LOAD SONG</div>
            <div className="mm-card-sub">14 songs on SD</div>
            <Icon name="sd" size={18}/>
          </div>
          <div className="mm-card">
            <div className="mm-card-num">03</div>
            <div className="mm-card-title">SAVE</div>
            <div className="mm-card-sub">Overwrite Pearl.s32</div>
            <Icon name="sd" size={18}/>
          </div>
          <div className="mm-card">
            <div className="mm-card-num">04</div>
            <div className="mm-card-title">SAVE AS…</div>
            <div className="mm-card-sub">Write new file</div>
          </div>
          <div className="mm-card">
            <div className="mm-card-num">05</div>
            <div className="mm-card-title">SOUND BROWSER</div>
            <div className="mm-card-sub">35 kits · 1859 files</div>
            <Icon name="wave" size={18}/>
          </div>
          <div className="mm-card">
            <div className="mm-card-num">06</div>
            <div className="mm-card-title">SAMPLE CUTTER</div>
            <div className="mm-card-sub">Slice WAVs in browser</div>
          </div>
          <div className="mm-card">
            <div className="mm-card-num">07</div>
            <div className="mm-card-title">UPLOAD FILES</div>
            <div className="mm-card-sub">From phone over WiFi</div>
            <Icon name="wifi" size={18}/>
          </div>
          <div className="mm-card">
            <div className="mm-card-num">08</div>
            <div className="mm-card-title">SETTINGS</div>
            <div className="mm-card-sub">Audio · Display · WiFi</div>
          </div>
          <div className="mm-card">
            <div className="mm-card-num">09</div>
            <div className="mm-card-title">ABOUT</div>
            <div className="mm-card-sub">v0.4.2 · OSS</div>
          </div>
        </div>

        <div className="mm-foot">
          <span className="num" style={{ color: "var(--t2)" }}>CPU 38% · PSRAM 18.4 MB · 1 WiFi client</span>
          <span style={{ flex: 1 }}/>
          <button className="btn">CANCEL</button>
        </div>
      </div>
    </div>

    <style>{`
      .mm-panel {
        position: absolute;
        left: 32px; right: 32px;
        bottom: 24px;
        top: 24px;
        background: var(--bg-2);
        border: 1px solid var(--line-3);
        border-radius: 12px;
        box-shadow: 0 30px 60px rgba(0,0,0,0.7);
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .mm-head {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        padding: 18px 24px;
        border-bottom: 1px solid var(--line);
        background: var(--bg-3);
      }
      .mm-close {
        width: 32px; height: 32px;
        background: transparent;
        border: 1px solid var(--line-2);
        color: var(--t1);
        border-radius: 2px;
        cursor: pointer;
        display: flex; align-items: center; justify-content: center;
      }
      .mm-grid {
        flex: 1;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1px;
        background: var(--line);
        overflow: hidden;
      }
      .mm-card {
        background: var(--bg-2);
        padding: 22px;
        display: flex;
        flex-direction: column;
        gap: 4px;
        position: relative;
        cursor: pointer;
      }
      .mm-card:hover { background: var(--bg-3); }
      .mm-card.primary { background: var(--lime-dim); }
      .mm-card.primary:hover { background: rgba(199,245,70,0.22); }
      .mm-card-num {
        font-family: var(--f-mono);
        font-size: 9px;
        letter-spacing: 0.2em;
        color: var(--t3);
      }
      .mm-card.primary .mm-card-num { color: var(--lime); }
      .mm-card-title {
        font-family: var(--f-mono);
        font-size: 16px;
        font-weight: 600;
        color: var(--t0);
        letter-spacing: 0.05em;
      }
      .mm-card.primary .mm-card-title { color: var(--lime); }
      .mm-card-sub {
        font-family: var(--f-mono);
        font-size: 10px;
        color: var(--t2);
      }
      .mm-card > svg { position: absolute; right: 22px; bottom: 18px; color: var(--t3); }
      .mm-card.primary > svg { color: var(--lime); }

      .mm-foot {
        display: flex; align-items: center; gap: 12px;
        height: 52px;
        padding: 0 24px;
        border-top: 1px solid var(--line);
        background: var(--bg-3);
        font-family: var(--f-mono);
        font-size: 10px;
      }
    `}</style>
  </div>
);

window.MainMenuOverlay = MainMenuOverlay;


// ===================================================================
//   SONG BROWSER + UPLOAD
// ===================================================================

const SongBrowser = () => (
  <div className="frame">
    <MiniTopBar
      title="Load Song"
      right={
        <div className="topbar-cell" style={{ width: 220, fontSize: 11, color: "var(--t1)" }}>
          <Icon name="sd" size={11} color="var(--t2)"/>
          <span style={{ fontFamily: "var(--f-mono)", textTransform: "none", letterSpacing: 0 }}>/sdcard/songs/  ·  14 files</span>
        </div>
      }
    />

    <div style={{ flex: 1, display: "flex", gap: 1, background: "var(--line)", overflow: "hidden" }}>
      {/* File list */}
      <div style={{ flex: 1, background: "var(--bg-1)", display: "flex", flexDirection: "column" }}>
        <div className="sb-thead">
          <div style={{ width: 36 }}>★</div>
          <div style={{ flex: 1 }}>NAME</div>
          <div style={{ width: 130 }}>MODIFIED</div>
          <div style={{ width: 80 }}>LANES</div>
          <div style={{ width: 90 }}>BPM</div>
          <div style={{ width: 80 }}>SIZE</div>
        </div>
        {[
          { n: "Pearl.s32",        m: "2026-05-26 14:22", l: 10, b: 120.0, s: "8.4 KB", sel: true, fav: true },
          { n: "Techno-1.s32",     m: "2026-05-25 09:11", l: 12, b: 128.0, s: "11.2 KB", fav: true },
          { n: "AmbientPad.s32",   m: "2026-05-20 22:48", l:  6, b:  72.0, s: "5.1 KB" },
          { n: "DemoTrack.s32",    m: "2026-05-15 10:33", l:  8, b: 124.0, s: "9.8 KB" },
          { n: "BoomBap-Sketch.s32",m:"2026-05-12 18:02", l:  4, b:  88.0, s: "3.2 KB" },
          { n: "Polyrhythm.s32",   m: "2026-05-08 13:55", l:  8, b: 130.0, s: "7.0 KB" },
          { n: "JamSession-1.s32", m: "2026-05-02 21:10", l: 14, b: 112.0, s: "14.5 KB" },
          { n: "808-Banger.s32",   m: "2026-04-28 16:24", l:  6, b: 140.0, s: "6.2 KB" },
          { n: "FieldExperiment.s32",m:"2026-04-21 11:48",l:  3, b:  60.0, s: "2.1 KB" },
        ].map((f, i) => (
          <div key={i} className={`song-row ${f.sel ? "sel" : ""}`}>
            <div style={{ width: 36, color: f.fav ? "var(--amber)" : "var(--t3)", fontSize: 14 }}>★</div>
            <div style={{ flex: 1, fontFamily: "var(--f-mono)", color: f.sel ? "var(--lime)" : "var(--t0)", fontSize: 13, fontWeight: 500 }}>{f.n}</div>
            <div style={{ width: 130, fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--t2)" }}>{f.m}</div>
            <div style={{ width: 80, fontFamily: "var(--f-mono)", fontSize: 12, color: "var(--t1)" }}>{f.l}</div>
            <div style={{ width: 90, fontFamily: "var(--f-mono)", fontSize: 12, color: "var(--t1)" }}>{f.b.toFixed(1)}</div>
            <div style={{ width: 80, fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--t2)" }}>{f.s}</div>
          </div>
        ))}
      </div>

      {/* Detail */}
      <div style={{ width: 360, background: "var(--bg-2)" }}>
        <div className="section-head">SELECTED</div>
        <div style={{ padding: "0 16px", display: "flex", flexDirection: "column", gap: 14 }}>
          <div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 18, color: "var(--lime)", fontWeight: 600 }}>Pearl.s32</div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--t2)" }}>/sdcard/songs/Pearl.s32</div>
          </div>

          <div className="sb-meta">
            <div><span>MODIFIED</span><span className="num">2026-05-26 14:22</span></div>
            <div><span>LANES</span><span className="num">10 (3 drum · 5 synth · 2 wav)</span></div>
            <div><span>BPM · SIG</span><span className="num">120.0 · 4/4 · 96 PPQN</span></div>
            <div><span>MASTER FX</span><span className="num">EQ5 → CMP → WIDTH → LIM</span></div>
            <div><span>SIZE</span><span className="num">8.4 KB</span></div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <button className="btn primary lg" style={{ width: "100%", justifyContent: "center" }}>
              <Icon name="play" size={11}/> LOAD SONG
            </button>
            <button className="btn lg" style={{ width: "100%", justifyContent: "center" }}>RENAME</button>
            <button className="btn lg" style={{ width: "100%", justifyContent: "center", color: "var(--red)", borderColor: "var(--red-dim)" }}>
              <Icon name="trash" size={11}/> DELETE
            </button>
          </div>
        </div>
      </div>
    </div>

    <style>{`
      .sb-thead {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 0 16px;
        height: 32px;
        background: var(--bg-2);
        border-bottom: 1px solid var(--line-2);
        font-family: var(--f-mono);
        font-size: 9px;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        color: var(--t2);
      }
      .song-row {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 0 16px;
        height: 52px;
        border-bottom: 1px solid var(--line);
        cursor: pointer;
      }
      .song-row:hover { background: var(--bg-2); }
      .song-row.sel {
        background: var(--lime-dim);
        border-left: 2px solid var(--lime);
        padding-left: 14px;
      }
      .sb-meta { display: flex; flex-direction: column; gap: 6px; padding: 8px 0; border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); }
      .sb-meta > div { display: flex; justify-content: space-between; font-family: var(--f-mono); font-size: 11px; }
      .sb-meta > div > span:first-child { color: var(--t2); letter-spacing: 0.1em; font-size: 9px; }
      .sb-meta > div > span:last-child  { color: var(--t0); }
    `}</style>
  </div>
);

window.SongBrowser = SongBrowser;


const UploadFiles = () => (
  <div className="frame">
    <MiniTopBar
      title="Upload Files"
      right={
        <div className="topbar-cell" style={{ width: 220, gap: 8 }}>
          <Icon name="wifi" size={12} color="var(--lime)"/>
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--lime)", textTransform: "none", letterSpacing: 0 }}>
            synth-32.local · 1 client
          </span>
        </div>
      }
    />

    <div style={{ flex: 1, display: "flex", gap: 1, background: "var(--line)", overflow: "hidden" }}>

      {/* Instructions / QR-like card */}
      <div style={{ width: 380, background: "var(--bg-2)", padding: 20, display: "flex", flexDirection: "column", gap: 16 }}>
        <div className="section-head" style={{ padding: 0 }}>OPEN ON YOUR PHONE</div>

        <div style={{
          background: "var(--bg-1)",
          border: "1px solid var(--line-2)",
          borderRadius: 6,
          padding: 24,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 18,
        }}>
          {/* "QR-like" code — placeholder stripe pattern, not real */}
          <div style={{ width: 180, height: 180, background: "var(--t0)", padding: 10, position: "relative" }}>
            <div style={{ position: "absolute", inset: 10, background:
              `radial-gradient(circle at 12% 12%, #0A0A0A 0 30%, transparent 30.5%),
               radial-gradient(circle at 12% 88%, #0A0A0A 0 30%, transparent 30.5%),
               radial-gradient(circle at 88% 12%, #0A0A0A 0 30%, transparent 30.5%),
               repeating-conic-gradient(from 0deg, #0A0A0A 0deg 30deg, transparent 30deg 60deg)`,
              backgroundSize: "30% 30%, 30% 30%, 30% 30%, 16px 16px",
              backgroundRepeat: "no-repeat, no-repeat, no-repeat, repeat",
              backgroundPosition: "left top, left bottom, right top, center",
            }}/>
          </div>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 9, letterSpacing: "0.2em", color: "var(--t2)", marginBottom: 4 }}>JOIN AP · OPEN</div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 14, color: "var(--lime)" }}>http://synth-32.local</div>
          </div>
        </div>

        <div style={{ fontFamily: "var(--f-sans)", fontSize: 12, color: "var(--t1)", lineHeight: 1.55 }}>
          Drag WAV files into the upload pane on your phone, or use the iOS / Android file picker.
          Each file streams directly to the SD card in 4 KB chunks. The sound browser refreshes
          automatically when uploads complete.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: "auto" }}>
          <div className="dev-stat-l" style={{ fontFamily: "var(--f-mono)", fontSize: 9, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--t2)" }}>ALSO REACHABLE AT</div>
          <span className="num" style={{ fontSize: 11, color: "var(--t1)" }}>http://synth.local</span>
          <span className="num" style={{ fontSize: 11, color: "var(--t1)" }}>http://synth32.local</span>
          <span className="num" style={{ fontSize: 11, color: "var(--t2)" }}>http://192.168.4.1</span>
        </div>
      </div>

      {/* Live upload progress */}
      <div style={{ flex: 1, background: "var(--bg-1)", display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div className="section-head" style={{ display: "flex", justifyContent: "space-between" }}>
          INCOMING UPLOADS
          <div style={{ display: "flex", gap: 8 }}>
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--lime)" }}>● LIVE</span>
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--t2)" }}>iPhone-Mark · sounds/my-kit/</span>
          </div>
        </div>

        <div style={{ flex: 1, overflow: "hidden", padding: "0 16px" }}>
          {[
            { n: "kick_round.wav",   s: "184 KB", p: 1.0,  d: "DONE" },
            { n: "snare_layer.wav",  s: "248 KB", p: 1.0,  d: "DONE" },
            { n: "hat_closed_03.wav",s: " 92 KB", p: 1.0,  d: "DONE" },
            { n: "tom_floor.wav",    s: "312 KB", p: 0.74, d: "230 / 312 KB" },
            { n: "perc_shaker.wav",  s: "176 KB", p: 0.12, d: "21 / 176 KB" },
            { n: "ride_brass.wav",   s: "896 KB", p: 0,    d: "QUEUED" },
            { n: "crash_dark.wav",   s: "1.2 MB", p: 0,    d: "QUEUED" },
          ].map((f, i) => (
            <div key={i} className="up-row">
              <div style={{ width: 28, color: f.p === 1 ? "var(--lime)" : "var(--t2)" }}>
                {f.p === 1 ? "✓" : <Icon name="wave" size={12} color="var(--amber)"/>}
              </div>
              <div style={{ flex: 1, fontFamily: "var(--f-mono)", fontSize: 12, color: "var(--t0)" }}>{f.n}</div>
              <div style={{ width: 60, fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--t2)" }}>{f.s}</div>
              <div style={{ flex: 1, maxWidth: 360 }}>
                <div className="fader" style={{ width: "100%" }}>
                  <div className="fader-fill" style={{ width: `${f.p*100}%`, background: f.p === 1 ? "var(--lime)" : "var(--amber)" }}/>
                </div>
              </div>
              <div style={{ width: 130, fontFamily: "var(--f-mono)", fontSize: 10, textAlign: "right", color: f.p === 1 ? "var(--lime)" : "var(--t1)" }}>{f.d}</div>
            </div>
          ))}
        </div>

        <div style={{
          padding: "16px 16px",
          background: "var(--bg-2)",
          borderTop: "1px solid var(--line)",
          display: "flex",
          alignItems: "center",
          gap: 16,
        }}>
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, letterSpacing: "0.18em", color: "var(--t2)" }}>SESSION</span>
          <span className="num" style={{ color: "var(--lime)", fontSize: 13 }}>3 / 7 files</span>
          <span className="num" style={{ color: "var(--t3)" }}>·</span>
          <span className="num" style={{ color: "var(--t1)", fontSize: 13 }}>524 KB / 3.1 MB</span>
          <div style={{ flex: 1 }}/>
          <span className="num" style={{ color: "var(--t1)", fontSize: 11 }}>throughput: 1.4 MB/s</span>
          <button className="btn ghost">CANCEL ALL</button>
        </div>
      </div>
    </div>

    <style>{`
      .up-row {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 12px 0;
        border-bottom: 1px solid var(--line);
      }
    `}</style>
  </div>
);

window.UploadFiles = UploadFiles;
