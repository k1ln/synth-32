/* global React, MiniTopBar, Drop, Icon, Knob */

// ===================================================================
//   MASTER SECTION + FX CHAIN EDITOR + ADSR
// ===================================================================

const FxSlot = ({ name, type, selected, params }) => (
  <div className={`fx-slot ${selected ? "selected" : ""} ${name ? "filled" : "empty"}`}>
    <div className="fx-slot-header">
      <span className="fx-slot-num num">{type}</span>
      <button className="fx-slot-x"><Icon name="x" size={9} /></button>
    </div>
    {name ? (
      <>
        <div className="fx-slot-name">{name}</div>
        <div className="fx-slot-params">{params}</div>
      </>
    ) : (
      <div className="fx-empty-hint">
        <Icon name="plus" size={14}/>
        <span>ADD FX</span>
      </div>
    )}
  </div>
);

const MasterSection = () => (
  <div className="frame">
    <MiniTopBar
      title="MASTER"
      right={
        <div className="topbar-cell" style={{ width: 130, gap: 8 }}>
          <span className="tiny">BPM</span>
          <span className="num" style={{ color: "var(--lime)", fontSize: 16 }}>120.0</span>
        </div>
      }
    />

    <div className="ms-grid">

      {/* LEFT — VOL/PAN + METERS */}
      <div className="ms-panel">
        <div className="section-head">VOLUME / PAN</div>
        <div style={{ display: "flex", gap: 20, padding: "0 16px 16px", alignItems: "center" }}>
          {/* Vertical master fader */}
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
            <div style={{ height: 200, width: 28, background: "var(--bg-3)", position: "relative", borderRadius: 2 }}>
              <div style={{
                position: "absolute", left: 0, right: 0, bottom: 0,
                height: "82%", background: "linear-gradient(0deg, var(--lime) 0%, var(--lime) 70%, var(--amber) 85%, var(--red) 100%)",
                borderRadius: 2,
              }}/>
              <div style={{
                position: "absolute", left: -6, right: -6,
                bottom: "82%", height: 6,
                background: "var(--t0)",
                borderRadius: 1,
                boxShadow: "0 0 0 1px rgba(0,0,0,0.4)",
              }}/>
            </div>
            <span className="num" style={{ fontSize: 13, color: "var(--t0)" }}>-1.6 dB</span>
            <span className="bb-label" style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--t2)", letterSpacing: "0.18em" }}>MASTER</span>
          </div>

          {/* L/R meters */}
          <div style={{ display: "flex", gap: 4 }}>
            {[72, 64].map((v, i) => (
              <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{ width: 12, height: 200, background: "var(--bg-3)", position: "relative", borderRadius: 2 }}>
                  <div style={{
                    position: "absolute", left: 0, right: 0, bottom: 0,
                    height: `${v}%`,
                    background: "linear-gradient(0deg, var(--lime) 0%, var(--lime) 60%, var(--amber) 80%, var(--red) 95%)",
                  }}/>
                </div>
                <span className="num" style={{ fontSize: 10, color: "var(--t1)" }}>{i === 0 ? "L" : "R"}</span>
                <span className="num" style={{ fontSize: 10, color: "var(--t2)" }}>-{(100-v)/10}.{(v%10)} dB</span>
              </div>
            ))}
          </div>

          {/* Pan knob */}
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10, marginLeft: 8 }}>
            <Knob label="PAN" value="C" deg={0} />
            <Knob label="WIDTH" value="100%" deg={30} color="amber" />
          </div>
        </div>
      </div>

      {/* MIDDLE — FX CHAIN */}
      <div className="ms-panel" style={{ flex: 1 }}>
        <div className="section-head">
          FX CHAIN
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--t3)" }}>SLOT 4 OF 6 SELECTED</span>
        </div>
        <div className="fx-chain">
          <FxSlot type="1" name="EQ5" params="LOW +1.5  MID 0  HIGH +0.5" />
          <div className="fx-arrow"><Icon name="chev-r" size={10}/></div>
          <FxSlot type="2" name="Compressor" params="-12 dB · 4:1 · 5/80 ms" />
          <div className="fx-arrow"><Icon name="chev-r" size={10}/></div>
          <FxSlot type="3" name="Stereo Width" params="WIDTH 110%" />
          <div className="fx-arrow"><Icon name="chev-r" size={10}/></div>
          <FxSlot type="4" name="Reverb" selected params="HALL · 0.55 · 15% WET" />
          <div className="fx-arrow"><Icon name="chev-r" size={10}/></div>
          <FxSlot type="5" name="" />
          <div className="fx-arrow"><Icon name="chev-r" size={10}/></div>
          <FxSlot type="6" name="Limiter" params="-0.3 dB · 50 ms" />
        </div>

        {/* Selected slot params */}
        <div className="section-head" style={{ marginTop: 8 }}>
          REVERB · SLOT 4
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--lime)" }}>● ENABLED</span>
        </div>
        <div className="fx-params-row">
          <Knob label="ROOM"    value="0.55"  deg={0}    />
          <Knob label="DAMP"    value="0.40"  deg={-30}  />
          <Knob label="WIDTH"   value="100%"  deg={30}   />
          <Knob label="PRE-DLY" value="20 ms" deg={-80}  />
          <Knob label="DRY"     value="-2.0"  deg={20}   />
          <Knob label="WET"     value="15%"   deg={-70}  color="amber"/>
          <div style={{ flex: 1 }} />
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <button className="btn">PRESET · HALL</button>
            <button className="btn ghost"><Icon name="trash" size={10}/> REMOVE</button>
          </div>
        </div>
      </div>

      {/* RIGHT — CLOCK */}
      <div className="ms-panel" style={{ width: 320 }}>
        <div className="section-head">CLOCK</div>
        <div style={{ padding: "0 16px", display: "flex", flexDirection: "column", gap: 14 }}>

          <div className="clock-row">
            <span className="clock-label">BPM</span>
            <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 10 }}>
              <div className="fader" style={{ flex: 1 }}><div className="fader-fill" style={{ width: "36%" }}/></div>
              <span className="num" style={{ fontSize: 18, color: "var(--lime)", width: 80, textAlign: "right" }}>120.0</span>
            </div>
          </div>
          <button className="btn lg" style={{ width: "100%", justifyContent: "center" }}>TAP TEMPO</button>

          <div className="clock-row">
            <span className="clock-label">PPQN</span>
            <div className="seg">
              {["24","48","96","192"].map((v,i) => (
                <div key={i} className={`seg-item ${v === "96" ? "on" : ""}`}>{v}</div>
              ))}
            </div>
          </div>

          <div className="clock-row">
            <span className="clock-label">TIME SIG</span>
            <div className="seg">
              {["4/4","3/4","5/4","6/8","7/8"].map((v,i) => (
                <div key={i} className={`seg-item ${v === "4/4" ? "on" : ""}`}>{v}</div>
              ))}
            </div>
          </div>

          <div className="clock-row">
            <span className="clock-label">SWING</span>
            <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 10 }}>
              <div className="fader" style={{ flex: 1 }}><div className="fader-fill" style={{ width: "0%" }}/></div>
              <span className="num" style={{ fontSize: 12, width: 50, textAlign: "right", color: "var(--t1)" }}>50%</span>
            </div>
          </div>

          <div style={{ borderTop: "1px solid var(--line)", paddingTop: 12, marginTop: 4 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span className="clock-label">PLAYHEAD</span>
              <span className="num" style={{ fontSize: 16, color: "var(--lime)" }}>027 · 03 · 12</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 6 }}>
              <span className="clock-label">CPU LOAD</span>
              <span className="num" style={{ fontSize: 12, color: "var(--t0)" }}>38% / 62%</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <style>{`
      .ms-grid {
        flex: 1;
        display: flex;
        gap: 1px;
        background: var(--line);
        overflow: hidden;
      }
      .ms-panel {
        background: var(--bg-1);
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .ms-panel:first-child { width: 320px; }

      .fx-chain {
        display: flex;
        align-items: stretch;
        padding: 0 16px;
        gap: 0;
      }
      .fx-slot {
        flex: 1;
        height: 110px;
        background: var(--bg-3);
        border: 1px solid var(--line-2);
        border-radius: 4px;
        display: flex;
        flex-direction: column;
        cursor: pointer;
      }
      .fx-slot.selected {
        border-color: var(--lime);
        background: var(--lime-dim);
      }
      .fx-slot.empty {
        background: transparent;
        border-style: dashed;
        border-color: var(--line-2);
      }
      .fx-slot-header {
        display: flex; align-items: center; justify-content: space-between;
        padding: 6px 8px 4px;
      }
      .fx-slot-num { font-family: var(--f-mono); font-size: 10px; color: var(--t2); }
      .fx-slot-x { background: none; border: none; color: var(--t3); cursor: pointer; padding: 2px; }
      .fx-slot.filled .fx-slot-x:hover { color: var(--red); }
      .fx-slot-name { padding: 0 8px; font-family: var(--f-mono); font-size: 13px; color: var(--t0); font-weight: 600; }
      .fx-slot.selected .fx-slot-name { color: var(--lime); }
      .fx-slot-params { padding: 4px 8px 8px; font-family: var(--f-mono); font-size: 9px; color: var(--t2); line-height: 1.4; }
      .fx-empty-hint {
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 4px;
        color: var(--t3);
        font-family: var(--f-mono);
        font-size: 9px;
        letter-spacing: 0.15em;
      }
      .fx-arrow {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 14px;
        color: var(--t3);
      }

      .fx-params-row {
        display: flex;
        align-items: flex-end;
        gap: 20px;
        padding: 8px 16px 16px;
      }

      .clock-row { display: flex; align-items: center; gap: 14px; min-height: 36px; }
      .clock-label {
        font-family: var(--f-mono);
        font-size: 10px;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        color: var(--t2);
        width: 70px;
      }
      .seg { display: flex; flex: 1; border: 1px solid var(--line-2); border-radius: 4px; overflow: hidden; }
      .seg-item {
        flex: 1;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: var(--f-mono);
        font-size: 11px;
        color: var(--t1);
        background: var(--bg-3);
        border-right: 1px solid var(--line);
        cursor: pointer;
      }
      .seg-item:last-child { border-right: none; }
      .seg-item.on { background: var(--lime); color: #0A0A0A; font-weight: 700; }
    `}</style>
  </div>
);

window.MasterSection = MasterSection;


// ===================================================================
//   FX CHAIN EDITOR (per-lane)
// ===================================================================

const FxChainEditor = () => (
  <div className="frame">
    <MiniTopBar
      title="FX — Drums · Lane 01"
      right={
        <>
          <button className="topbar-cell action" style={{ background: "transparent", border: "none", borderLeft: "1px solid var(--line)", borderRight: "1px solid var(--line)", cursor: "pointer", color: "var(--t0)" }}>
            <Icon name="plus" size={12}/> ADD FX
          </button>
        </>
      }
    />

    <div style={{ flex: 1, display: "flex", flexDirection: "column", padding: 16, gap: 16, overflow: "hidden" }}>

      {/* ADSR strip — separate from FX chain (always present) */}
      <div className="adsr-strip">
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span className="bb-label" style={{ color: "var(--lime)", letterSpacing: "0.18em", fontFamily: "var(--f-mono)", fontSize: 10, textTransform: "uppercase" }}>LANE ADSR</span>
          <span className="num" style={{ fontSize: 10, color: "var(--t3)" }}>— always-on volume envelope</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 24, marginTop: 12 }}>
          {/* ADSR preview */}
          <svg viewBox="0 0 220 60" style={{ width: 220, height: 60 }}>
            <path d="M 0 58 L 25 4 L 60 30 L 140 30 L 200 58" stroke="var(--lime)" strokeWidth="2" fill="none" />
            <path d="M 0 58 L 25 4 L 60 30 L 140 30 L 200 58 L 0 58" fill="rgba(199,245,70,0.12)" stroke="none"/>
            <line x1="25" y1="58" x2="25" y2="4" stroke="var(--line-2)" strokeDasharray="2 2"/>
            <line x1="60" y1="58" x2="60" y2="30" stroke="var(--line-2)" strokeDasharray="2 2"/>
            <line x1="140" y1="58" x2="140" y2="30" stroke="var(--line-2)" strokeDasharray="2 2"/>
            <text x="12" y="56" fontFamily="var(--f-mono)" fontSize="7" fill="var(--t3)">A</text>
            <text x="40" y="56" fontFamily="var(--f-mono)" fontSize="7" fill="var(--t3)">D</text>
            <text x="95" y="56" fontFamily="var(--f-mono)" fontSize="7" fill="var(--t3)">S</text>
            <text x="165" y="56" fontFamily="var(--f-mono)" fontSize="7" fill="var(--t3)">R</text>
          </svg>
          <Knob label="ATTACK"  value="4 ms"    deg={-110}/>
          <Knob label="DECAY"   value="120 ms"  deg={-30} />
          <Knob label="SUSTAIN" value="0.55"    deg={0}   />
          <Knob label="RELEASE" value="380 ms"  deg={30}  />
        </div>
      </div>

      {/* FX chain row */}
      <div>
        <div className="section-head" style={{ padding: 0, marginBottom: 8 }}>
          FX CHAIN
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--t3)" }}>3 OF 6 SLOTS USED</span>
        </div>
        <div className="fx-chain" style={{ padding: 0 }}>
          <FxSlot type="1" name="Compressor" params="-12 dB · 4:1 · 5/80 ms" />
          <div className="fx-arrow"><Icon name="chev-r" size={10}/></div>
          <FxSlot type="2" name="EQ3" selected params="L +1.5  M -0.5  H +2.0" />
          <div className="fx-arrow"><Icon name="chev-r" size={10}/></div>
          <FxSlot type="3" name="Transient Shaper" params="ATK +3 dB  SUS -2 dB" />
          <div className="fx-arrow"><Icon name="chev-r" size={10}/></div>
          <FxSlot type="4" name="" />
          <div className="fx-arrow"><Icon name="chev-r" size={10}/></div>
          <FxSlot type="5" name="" />
          <div className="fx-arrow"><Icon name="chev-r" size={10}/></div>
          <FxSlot type="6" name="" />
        </div>
      </div>

      {/* Selected slot params (EQ3 detail) */}
      <div style={{ flex: 1, background: "var(--bg-2)", border: "1px solid var(--line-2)", borderRadius: 6, padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div className="section-head" style={{ borderBottom: "1px solid var(--line)" }}>
          EQ3 · SLOT 2
          <div style={{ display: "flex", gap: 8 }}>
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--lime)" }}>● ENABLED</span>
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--t3)" }}>WET 100%</span>
          </div>
        </div>

        {/* EQ curve visualization */}
        <div style={{ height: 140, background: "var(--bg-1)", margin: 16, border: "1px solid var(--line-2)", borderRadius: 4, position: "relative", overflow: "hidden" }}>
          {/* Grid */}
          <svg viewBox="0 0 600 140" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
            {[40, 80, 100].map(y => <line key={y} x1="0" y1={y} x2="600" y2={y} stroke="var(--line)" strokeWidth="0.5"/>)}
            {[100, 200, 300, 400, 500].map(x => <line key={x} x1={x} y1="0" x2={x} y2="140" stroke="var(--line)" strokeWidth="0.5"/>)}
            {/* 0 dB reference */}
            <line x1="0" y1="70" x2="600" y2="70" stroke="var(--line-3)" strokeDasharray="3 3"/>
            {/* EQ curve */}
            <path d="M 0 56 Q 80 52 150 64 Q 280 84 380 78 Q 480 70 600 50" stroke="var(--lime)" strokeWidth="2" fill="none"/>
            <path d="M 0 56 Q 80 52 150 64 Q 280 84 380 78 Q 480 70 600 50 L 600 140 L 0 140 Z" fill="rgba(199,245,70,0.08)" stroke="none"/>
            {/* Band markers */}
            <circle cx="80" cy="56" r="5" fill="var(--lime)"/>
            <circle cx="300" cy="76" r="5" fill="var(--lime)" stroke="white" strokeWidth="2"/>
            <circle cx="500" cy="60" r="5" fill="var(--lime)"/>
            <text x="80" y="22" textAnchor="middle" fontFamily="var(--f-mono)" fontSize="8" fill="var(--t1)">LOW</text>
            <text x="300" y="22" textAnchor="middle" fontFamily="var(--f-mono)" fontSize="8" fill="var(--t1)">MID</text>
            <text x="500" y="22" textAnchor="middle" fontFamily="var(--f-mono)" fontSize="8" fill="var(--t1)">HIGH</text>
          </svg>

          {/* dB labels */}
          <div style={{ position: "absolute", left: 4, top: 2, fontFamily: "var(--f-mono)", fontSize: 8, color: "var(--t3)" }}>+12 dB</div>
          <div style={{ position: "absolute", left: 4, bottom: 2, fontFamily: "var(--f-mono)", fontSize: 8, color: "var(--t3)" }}>-12 dB</div>
          <div style={{ position: "absolute", left: 4, top: "50%", fontFamily: "var(--f-mono)", fontSize: 8, color: "var(--t3)", transform: "translateY(-50%)" }}>0</div>
        </div>

        <div className="fx-params-row" style={{ padding: "0 16px 16px" }}>
          <Knob label="LOW FREQ" value="120 Hz" deg={-80}/>
          <Knob label="LOW GAIN" value="+1.5"   deg={20}/>
          <div className="bb-divider" style={{ height: 60 }}/>
          <Knob label="MID FREQ" value="800 Hz" deg={-20}/>
          <Knob label="MID Q"    value="0.7"    deg={-40}/>
          <Knob label="MID GAIN" value="-0.5"   deg={-10}/>
          <div className="bb-divider" style={{ height: 60 }}/>
          <Knob label="HIGH FREQ" value="6.5 kHz" deg={40}/>
          <Knob label="HIGH GAIN" value="+2.0"    deg={40}/>
        </div>
      </div>
    </div>

    <style>{`
      .adsr-strip {
        background: var(--bg-2);
        border: 1px solid var(--line-2);
        border-radius: 6px;
        padding: 14px 16px;
      }
      .bb-divider { width: 1px; height: 36px; background: var(--line-2); }
    `}</style>
  </div>
);

window.FxChainEditor = FxChainEditor;
