/* global React, MiniTopBar, Drop, Icon, Knob */

// ===================================================================
//   LIVE PLAY MODE
// ===================================================================

const LIVE_DRUM_ROWS = [
  { name: "KICK",  hit: 1 },
  { name: "SNARE", hit: 0 },
  { name: "HH-CL", hit: 0.4 },
  { name: "HH-OP", hit: 0 },
  { name: "CLAP",  hit: 0 },
  { name: "TOM-H", hit: 0 },
  { name: "RIDE",  hit: 0.7 },
  { name: "CRASH", hit: 0 },
];

const PianoKeys = ({ octaves = 2, highlights = [], baseNote = 48 }) => {
  // Render flat 2-octave keyboard
  const totalKeys = octaves * 7; // white keys
  const totalNotes = octaves * 12;
  return (
    <div style={{ position: "relative", display: "flex", height: 130, flex: 1, background: "var(--bg-0)", borderRadius: 4, padding: 2 }}>
      {/* White keys */}
      <div style={{ display: "flex", flex: 1, gap: 2 }}>
        {Array.from({ length: totalKeys }).map((_, i) => {
          const note = baseNote + Math.floor(i/7)*12 + [0,2,4,5,7,9,11][i%7];
          const on = highlights.includes(note);
          return (
            <div key={i} style={{
              flex: 1,
              background: on ? "var(--lime)" : "#E8E8EC",
              borderRadius: 2,
              display: "flex",
              alignItems: "flex-end",
              justifyContent: "center",
              padding: "0 0 8px",
              fontFamily: "var(--f-mono)",
              fontSize: 9,
              color: on ? "#0A0A0A" : "#74747D",
              fontWeight: 600,
              boxShadow: on ? "0 0 16px var(--lime-glow)" : "inset 0 -3px 0 rgba(0,0,0,0.08)",
            }}>
              {i%7 === 0 ? `C${Math.floor(note/12)-1}` : ""}
            </div>
          );
        })}
      </div>
      {/* Black keys (absolute overlay) */}
      <div style={{ position: "absolute", inset: 2, display: "flex", pointerEvents: "none" }}>
        {Array.from({ length: totalKeys }).map((_, i) => {
          const hasBlackAfter = [0,1,3,4,5].includes(i % 7) && i < totalKeys - 1;
          const note = baseNote + Math.floor(i/7)*12 + [0,2,4,5,7,9,11][i%7] + 1;
          const on = highlights.includes(note);
          return (
            <div key={i} style={{ flex: 1, position: "relative" }}>
              {hasBlackAfter && (
                <div style={{
                  position: "absolute",
                  right: "-25%",
                  top: 0,
                  width: "50%",
                  height: "62%",
                  background: on ? "var(--lime)" : "#0A0A0C",
                  borderRadius: "0 0 3px 3px",
                  zIndex: 2,
                  boxShadow: on ? "0 0 14px var(--lime-glow)" : "0 2px 0 rgba(0,0,0,0.5)",
                }}/>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

const LanePanel = ({ children, title, type, accent, num, mute, editBtn = true }) => (
  <div className="live-lane">
    <div className="live-lane-head">
      <div style={{ width: 3, height: 22, background: accent, marginRight: 10 }}/>
      <span className="live-lane-num">{String(num).padStart(2,"0")}</span>
      <span className="live-lane-title">{title}</span>
      <span className="chip" style={{ background: "transparent", border: "none", color: accent, fontSize: 9, padding: 0 }}>{type}</span>
      <div style={{ flex: 1 }}/>
      <button className={`mu-btn ${mute ? "on" : ""}`}><Icon name={mute ? "mute" : "unmute"} size={10}/></button>
      {editBtn && <button className="btn" style={{ height: 28, fontSize: 10 }}>EDIT</button>}
    </div>
    <div className="live-lane-body">
      {children}
    </div>
    <style>{`
      .live-lane { background: var(--bg-2); border: 1px solid var(--line-2); border-radius: 6px; overflow: hidden; }
      .live-lane-head {
        display: flex; align-items: center;
        height: 36px;
        padding: 0 12px 0 0;
        background: var(--bg-3);
        border-bottom: 1px solid var(--line);
        gap: 10px;
      }
      .live-lane-num { font-family: var(--f-mono); font-size: 11px; color: var(--t2); }
      .live-lane-title { font-family: var(--f-mono); font-size: 13px; color: var(--t0); font-weight: 600; }
      .live-lane-body { padding: 10px 12px; }
      .mu-btn { width: 28px; height: 28px; background: var(--bg-3); border: 1px solid var(--line-2); border-radius: 2px; color: var(--t2); display: flex; align-items: center; justify-content: center; cursor: pointer; }
      .mu-btn.on { background: var(--red); color: white; border-color: var(--red); }
    `}</style>
  </div>
);

const LivePlayMode = () => (
  <div className="frame">
    <MiniTopBar
      title="LIVE PLAY"
      right={
        <>
          <div className="topbar-cell" style={{ width: 140, gap: 8 }}>
            <span className="tiny">BPM</span>
            <span className="num" style={{ color: "var(--lime)", fontSize: 16 }}>120.0</span>
          </div>
          <div className="topbar-cell" style={{ width: 110, gap: 6 }}>
            <Icon name="rec" size={10} color="var(--magenta)" />
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--magenta)", letterSpacing: "0.1em" }}>LIVE</span>
          </div>
        </>
      }
    />

    <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, padding: 12, overflow: "hidden" }}>

      {/* DRUM PADS — large lane */}
      <LanePanel title="Drums" type="DRUM" accent="var(--lime)" num={1} mute={false}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gridTemplateRows: "1fr 1fr", gap: 6, height: 240 }}>
          {LIVE_DRUM_ROWS.map((row, i) => (
            <div key={i} className="pad" style={{
              background: row.hit > 0.5 ? "var(--lime)" : "var(--bg-3)",
              color: row.hit > 0.5 ? "#0A0A0A" : "var(--t1)",
              border: "1px solid",
              borderColor: row.hit > 0.5 ? "var(--lime)" : "var(--line-2)",
              boxShadow: row.hit > 0.5 ? "0 0 24px var(--lime-glow)" : "none",
              transition: "none",
            }}>
              <span className="pad-name">{row.name}</span>
              <span className="pad-vel" style={{ opacity: row.hit }}>{row.hit > 0 ? "●" : "○"}</span>
            </div>
          ))}
        </div>
        <style>{`
          .pad {
            border-radius: 4px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
            padding: 10px;
            font-family: var(--f-mono);
            cursor: pointer;
            user-select: none;
          }
          .pad-name { font-size: 13px; font-weight: 700; letter-spacing: 0.1em; }
          .pad-vel { font-size: 14px; }
        `}</style>
      </LanePanel>

      {/* SYNTH 1 — Bass piano */}
      <LanePanel title="Bass" type="SUBTRACTIVE MONO" accent="var(--cyan)" num={2} mute={false}>
        <PianoKeys octaves={2} highlights={[50, 53]} baseNote={36} />
        <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center" }}>
          <button className="btn" style={{ height: 28, fontSize: 10 }}>
            <Icon name="chev-l" size={10}/> OCT
          </button>
          <button className="btn" style={{ height: 28, fontSize: 10 }}>
            OCT <Icon name="chev-r" size={10}/>
          </button>
          <div style={{ flex: 1 }} />
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--t2)", letterSpacing: "0.12em" }}>C2 — C4</span>
        </div>
      </LanePanel>

      {/* SYNTH 2 — Lead piano */}
      <LanePanel title="Lead" type="SUPER SAW" accent="var(--cyan)" num={3} mute={false}>
        <PianoKeys octaves={2} highlights={[60, 64, 67]} baseNote={48} />
        <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center" }}>
          <button className="btn" style={{ height: 28, fontSize: 10 }}><Icon name="chev-l" size={10}/> OCT</button>
          <button className="btn" style={{ height: 28, fontSize: 10 }}>OCT <Icon name="chev-r" size={10}/></button>
          <div style={{ flex: 1 }} />
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--t2)", letterSpacing: "0.12em" }}>C3 — C5</span>
        </div>
      </LanePanel>

      {/* WAV row — scrubber + trigger */}
      <LanePanel title="Loop A · drumloop_124.wav" type="WAV" accent="var(--amber)" num={5} mute={false}>
        {/* Waveform mini */}
        <div style={{ height: 100, background: "var(--bg-1)", border: "1px solid var(--line-2)", borderRadius: 4, position: "relative", overflow: "hidden", padding: 0 }}>
          {/* Waveform peaks (decorative) */}
          <svg viewBox="0 0 600 100" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
            {Array.from({ length: 120 }).map((_, i) => {
              const x = i * 5 + 2;
              const h = 20 + Math.abs(Math.sin(i * 0.31) * 32) + Math.abs(Math.sin(i * 0.07) * 12);
              return <rect key={i} x={x} y={50 - h/2} width="3" height={h} fill="var(--amber)" opacity={0.7} />;
            })}
          </svg>
          {/* Playback position */}
          <div style={{ position: "absolute", left: "40%", top: 0, bottom: 0, width: 2, background: "var(--lime)", boxShadow: "0 0 8px var(--lime)" }}/>
          <div style={{ position: "absolute", left: 0, top: 0, width: "40%", bottom: 0, background: "rgba(199,245,70,0.05)" }}/>
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center" }}>
          <button className="btn"><Icon name="play" size={10}/> TRIG</button>
          <button className="btn"><Icon name="stop" size={10}/> STOP</button>
          <div style={{ flex: 1 }} />
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--t2)" }}>00:01.872 / 00:04.680</span>
        </div>
      </LanePanel>

    </div>

    {/* Bottom: master + transport */}
    <div className="live-footer">
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <button className="btn primary lg" style={{ width: 56, padding: 0, justifyContent: "center" }}><Icon name="play" size={14}/></button>
        <button className="btn lg" style={{ width: 56, padding: 0, justifyContent: "center" }}><Icon name="stop" size={14}/></button>
      </div>
      <div className="bb-divider" />
      <div style={{ display: "flex", alignItems: "center", gap: 10, flex: 1 }}>
        <span className="bb-label">MASTER</span>
        <div className="fader" style={{ flex: 1, maxWidth: 240 }}><div className="fader-fill" style={{ width: "82%" }}/></div>
        <span className="num" style={{ fontSize: 11, color: "var(--t0)" }}>-1.6 dB</span>
      </div>
      <div className="meter" style={{ width: 220 }}>
        <div className="meter-row"><span style={{ width: 8 }}>L</span><div className="meter-bar"><div className="meter-fill" style={{ width: "72%" }}/></div></div>
        <div className="meter-row"><span style={{ width: 8 }}>R</span><div className="meter-bar"><div className="meter-fill" style={{ width: "65%" }}/></div></div>
      </div>
      <style>{`
        .live-footer {
          height: 64px;
          background: var(--bg-2);
          border-top: 1px solid var(--line-2);
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 0 16px;
        }
        .bb-divider { width: 1px; height: 32px; background: var(--line-2); }
        .bb-label { font-family: var(--f-mono); font-size: 9px; letter-spacing: 0.18em; text-transform: uppercase; color: var(--t2); }
      `}</style>
    </div>
  </div>
);

window.LivePlayMode = LivePlayMode;
