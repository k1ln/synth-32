/* global React, V2MiniBar, V2Icon, V2Knob */

// ===================================================================
//   v2 FX CHAIN + ADSR (per-lane detail)
// ===================================================================

const V2FxChain = () => (
  <div className="frame2">
    <V2MiniBar
      title="FX · Drums"
      right={
        <div className="ctrl">
          <button className="v2-btn sm"><V2Icon name="plus" size={16}/> ADD</button>
        </div>
      }
    />

    <div style={{ flex: 1, display: "flex", flexDirection: "column", padding: 16, gap: 16, overflow: "hidden" }}>

      {/* ADSR row */}
      <div className="fx2-adsr">
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 16, letterSpacing: "0.18em", color: "var(--lime)" }}>LANE ADSR</span>
        <div style={{ display: "flex", alignItems: "center", gap: 20, marginTop: 12 }}>
          {/* ADSR curve */}
          <svg viewBox="0 0 200 60" style={{ width: 200, height: 60, flexShrink: 0 }}>
            <path d="M 0 58 L 22 4 L 55 28 L 130 28 L 185 58" stroke="var(--lime)" strokeWidth="2.5" fill="none"/>
            <path d="M 0 58 L 22 4 L 55 28 L 130 28 L 185 58 L 0 58" fill="rgba(199,245,70,0.1)"/>
          </svg>
          <V2Knob label="A" value="4ms"  deg={-110}/>
          <V2Knob label="D" value="120"  deg={-30}/>
          <V2Knob label="S" value="0.55" deg={0}/>
          <V2Knob label="R" value="380"  deg={30}/>
        </div>
      </div>

      {/* FX chain */}
      <div>
        <div className="v2-section-head" style={{ padding: "0 0 12px" }}>FX CHAIN · 3 / 6</div>
        <div className="fx2-chain">
          {[
            { name: "COMP", on: true },
            { name: "EQ3",  on: true, sel: true },
            { name: "T.SHP", on: true },
            { name: null },
            { name: null },
            { name: null },
          ].map((fx, i) => (
            <React.Fragment key={i}>
              {i > 0 && <div className="fx2-arrow"><V2Icon name="chev-r" size={16} color="var(--t3)"/></div>}
              <div className={`fx2-slot ${fx.name ? "filled" : "empty"} ${fx.sel ? "sel" : ""}`}>
                <span className="fx2-slot-num">{i+1}</span>
                {fx.name ? (
                  <span className="fx2-slot-name">{fx.name}</span>
                ) : (
                  <V2Icon name="plus" size={20} color="var(--t3)"/>
                )}
              </div>
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Selected FX params */}
      <div className="fx2-detail">
        <div className="v2-section-head" style={{ padding: "12px 20px 8px", borderBottom: "2px solid var(--line)" }}>
          <span>EQ3 · SLOT 2</span>
          <span style={{ color: "var(--lime)", fontFamily: "var(--f-mono)", fontSize: 16 }}>● ON</span>
        </div>
        <div style={{ display: "flex", gap: 28, padding: "16px 24px", alignItems: "flex-end", justifyContent: "center" }}>
          <V2Knob label="LOW F" value="120 Hz" deg={-80}/>
          <V2Knob label="LOW G" value="+1.5"   deg={20}/>
          <div style={{ width: 2, height: 60, background: "var(--line-2)" }}/>
          <V2Knob label="MID F" value="800 Hz"  deg={-20}/>
          <V2Knob label="MID Q" value="0.7"     deg={-40}/>
          <V2Knob label="MID G" value="-0.5"    deg={-10}/>
          <div style={{ width: 2, height: 60, background: "var(--line-2)" }}/>
          <V2Knob label="HI F"  value="6.5 kHz" deg={40}/>
          <V2Knob label="HI G"  value="+2.0"    deg={40}/>
        </div>
      </div>
    </div>

    <style>{`
      .fx2-adsr {
        background: var(--bg-2);
        border: 2px solid var(--line-2);
        border-radius: 10px;
        padding: 16px 20px;
      }
      .fx2-chain {
        display: flex;
        align-items: center;
        gap: 0;
      }
      .fx2-arrow {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 20px;
        flex-shrink: 0;
      }
      .fx2-slot {
        flex: 1;
        height: 80px;
        background: var(--bg-3);
        border: 2px solid var(--line-2);
        border-radius: 8px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 6px;
        cursor: pointer;
      }
      .fx2-slot.empty { border-style: dashed; background: transparent; }
      .fx2-slot.sel {
        border-color: var(--lime);
        background: var(--lime-dim);
      }
      .fx2-slot-num {
        font-family: var(--f-mono);
        font-size: 13px;
        color: var(--t3);
      }
      .fx2-slot-name {
        font-family: var(--f-mono);
        font-size: 22px;
        font-weight: 600;
        color: var(--t0);
      }
      .fx2-slot.sel .fx2-slot-name { color: var(--lime); }

      .fx2-detail {
        flex: 1;
        background: var(--bg-2);
        border: 2px solid var(--line-2);
        border-radius: 10px;
        overflow: hidden;
      }
    `}</style>
  </div>
);

window.V2FxChain = V2FxChain;


// ===================================================================
//   v2 SOUND BROWSER — big list, one column at a time
// ===================================================================

const V2SoundBrowser = () => (
  <div className="frame2">
    <V2MiniBar
      title="Sounds"
      right={
        <div className="ctrl">
          <span className="ctrl-label">SD</span>
          <span className="ctrl-val" style={{ fontSize: 18 }}>35 kits · 437 MB</span>
        </div>
      }
    />

    <div style={{ flex: 1, display: "flex", gap: 2, background: "var(--line)", overflow: "hidden" }}>

      {/* Kit list */}
      <div style={{ width: 380, background: "var(--bg-1)", display: "flex", flexDirection: "column" }}>
        <div className="v2-section-head">KITS</div>
        <div style={{ flex: 1, overflow: "hidden" }}>
          {[
            { name: "AVL · Pearl-22", n: 36, sel: true },
            { name: "AVL · BlondeBop", n: 28 },
            { name: "Classic · 808",   n: 25 },
            { name: "Classic · 909",   n: 28 },
            { name: "Linn · LinnDrum", n: 23 },
            { name: "Roland · TR-707", n: 24 },
            { name: "Boss · DR-110",   n: 18 },
          ].map((k, i) => (
            <div key={i} className={`sb2-kit ${k.sel ? "sel" : ""}`}>
              <span className="sb2-kit-name">{k.name}</span>
              <span className="sb2-kit-n">{k.n}</span>
              {k.sel && <V2Icon name="chev-r" size={20}/>}
            </div>
          ))}
        </div>
      </div>

      {/* File list */}
      <div style={{ flex: 1, background: "var(--bg-1)", display: "flex", flexDirection: "column" }}>
        <div className="v2-section-head">
          PEARL-22 · 36 FILES
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 14, color: "var(--t3)" }}>12.4 MB</span>
        </div>
        <div style={{ flex: 1, overflow: "hidden" }}>
          {[
            { n: "Pearl-22-Kick-1.wav",    t: "0.42s", sel: true },
            { n: "Pearl-22-Kick-2.wav",    t: "0.51s" },
            { n: "Pearl-14-Snare-1.wav",   t: "0.62s" },
            { n: "Pearl-14-Snare-2.wav",   t: "0.58s" },
            { n: "Pearl-Hat-Cl-1.wav",     t: "0.18s" },
            { n: "Pearl-Hat-Op-1.wav",     t: "1.42s" },
            { n: "Pearl-Tom-Hi-1.wav",     t: "0.74s" },
          ].map((f, i) => (
            <div key={i} className={`sb2-file ${f.sel ? "sel" : ""}`}>
              <button className={`sb2-play ${f.sel ? "on" : ""}`}>
                <V2Icon name="play" size={16}/>
              </button>
              <span className="sb2-file-name">{f.n}</span>
              <span className="sb2-file-dur">{f.t}</span>
            </div>
          ))}
        </div>
        <div style={{ height: 72, display: "flex", alignItems: "center", gap: 12, padding: "0 24px", background: "var(--bg-2)", borderTop: "2px solid var(--line)" }}>
          <button className="v2-btn primary" style={{ flex: 1, justifyContent: "center" }}>
            <V2Icon name="chev-r" size={18}/> ASSIGN
          </button>
        </div>
      </div>
    </div>

    <style>{`
      .sb2-kit, .sb2-file {
        display: flex;
        align-items: center;
        gap: 16px;
        height: 72px;
        padding: 0 24px;
        border-bottom: 2px solid var(--line);
        cursor: pointer;
      }
      .sb2-kit:active, .sb2-file:active { background: var(--bg-2); }
      .sb2-kit.sel, .sb2-file.sel {
        background: var(--lime-dim);
        border-left: 4px solid var(--lime);
        padding-left: 20px;
      }
      .sb2-kit-name {
        flex: 1;
        font-family: var(--f-mono);
        font-size: 22px;
        color: var(--t0);
      }
      .sb2-kit.sel .sb2-kit-name { color: var(--lime); font-weight: 600; }
      .sb2-kit-n {
        font-family: var(--f-mono);
        font-size: 18px;
        color: var(--t2);
      }

      .sb2-play {
        width: 44px;
        height: 44px;
        background: var(--bg-3);
        border: 2px solid var(--line-2);
        border-radius: 50%;
        color: var(--lime);
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        flex-shrink: 0;
      }
      .sb2-play.on { background: var(--lime); color: #0A0A0A; border-color: var(--lime); }
      .sb2-file-name {
        flex: 1;
        font-family: var(--f-mono);
        font-size: 22px;
        color: var(--t0);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .sb2-file.sel .sb2-file-name { color: var(--lime); font-weight: 600; }
      .sb2-file-dur {
        font-family: var(--f-mono);
        font-size: 18px;
        color: var(--t2);
      }
    `}</style>
  </div>
);

window.V2SoundBrowser = V2SoundBrowser;


// ===================================================================
//   v2 SETTINGS — big rows, simple toggles
// ===================================================================

const V2Settings = () => (
  <div className="frame2">
    <V2MiniBar
      title="Settings"
      right={
        <div className="ctrl">
          <V2Icon name="sd" size={18} color="var(--lime)"/>
          <span className="ctrl-val" style={{ color: "var(--lime)", fontSize: 18 }}>SAVED</span>
        </div>
      }
    />

    <div style={{ flex: 1, overflow: "hidden" }}>
      {[
        { label: "Output Volume", val: "75%", fader: true, pct: 75 },
        { label: "I2S Buffer", val: "512 frames", seg: ["256","512","1024"], active: "512" },
        { label: "Brightness", val: "80%", fader: true, pct: 80 },
        { label: "Default BPM", val: "120.0", plain: true },
        { label: "Default Loop", val: "2 bars", seg: ["1","2","4","8"], active: "2" },
        { label: "WiFi AP", val: "synth-32", plain: true },
        { label: "Hostname", val: "synth-32.local", lime: true },
        { label: "Auto-save", val: true, toggle: true },
      ].map((row, i) => (
        <div key={i} className="st2-row">
          <span className="st2-label">{row.label}</span>
          <div className="st2-ctrl">
            {row.fader && (
              <div style={{ display: "flex", alignItems: "center", gap: 16, width: 340 }}>
                <div className="v2-fader" style={{ flex: 1 }}>
                  <div className="v2-fader-fill" style={{ width: `${row.pct}%`, background: "var(--lime)" }}/>
                </div>
                <span style={{ fontFamily: "var(--f-mono)", fontSize: 24, color: "var(--t0)", width: 70, textAlign: "right" }}>{row.val}</span>
              </div>
            )}
            {row.seg && (
              <div className="v2-seg" style={{ width: 320 }}>
                {row.seg.map(v => (
                  <div key={v} className={`v2-seg-item ${v === row.active ? "on" : ""}`} style={{ height: 52, fontSize: 20 }}>{v}</div>
                ))}
              </div>
            )}
            {row.plain && (
              <span style={{ fontFamily: "var(--f-mono)", fontSize: 24, color: row.lime ? "var(--lime)" : "var(--t0)" }}>{row.val}</span>
            )}
            {row.lime && (
              <span style={{ fontFamily: "var(--f-mono)", fontSize: 24, color: "var(--lime)" }}>{row.val}</span>
            )}
            {row.toggle && (
              <div className={`v2-toggle ${row.val ? "on" : ""}`}><div className="v2-toggle-knob"/></div>
            )}
          </div>
        </div>
      ))}
    </div>

    <style>{`
      .st2-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 80px;
        padding: 0 28px;
        border-bottom: 2px solid var(--line);
      }
      .st2-label {
        font-family: var(--f-sans);
        font-size: 24px;
        color: var(--t0);
      }
      .st2-ctrl { display: flex; align-items: center; }
    `}</style>
  </div>
);

window.V2Settings = V2Settings;
