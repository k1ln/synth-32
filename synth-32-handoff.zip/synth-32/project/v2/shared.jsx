/* global React */
/* v2 shared components — sized for 5" 293ppi handheld */

// ---------- Icons (bigger strokes for small screen) ----------
const V2Icon = ({ name, size = 28, color = "currentColor" }) => {
  const s = { width: size, height: size, color, display: "block" };
  const stroke = { fill: "none", stroke: "currentColor", strokeWidth: 2.2, strokeLinecap: "round", strokeLinejoin: "round" };
  switch (name) {
    case "play":   return <svg viewBox="0 0 16 16" style={s}><polygon points="4,2 14,8 4,14" fill="currentColor"/></svg>;
    case "stop":   return <svg viewBox="0 0 16 16" style={s}><rect x="3" y="3" width="10" height="10" fill="currentColor"/></svg>;
    case "back":   return <svg viewBox="0 0 16 16" style={s}><path d="M10 2 L4 8 L10 14" {...stroke}/></svg>;
    case "menu":   return <svg viewBox="0 0 16 16" style={s}><path d="M2 4h12 M2 8h12 M2 12h12" {...stroke}/></svg>;
    case "plus":   return <svg viewBox="0 0 16 16" style={s}><path d="M8 3v10 M3 8h10" {...stroke}/></svg>;
    case "x":      return <svg viewBox="0 0 16 16" style={s}><path d="M3 3l10 10 M13 3L3 13" {...stroke}/></svg>;
    case "chev-d": return <svg viewBox="0 0 16 16" style={s}><path d="M3 6l5 5 5-5" {...stroke}/></svg>;
    case "chev-r": return <svg viewBox="0 0 16 16" style={s}><path d="M6 2l5 6-5 6" {...stroke}/></svg>;
    case "chev-l": return <svg viewBox="0 0 16 16" style={s}><path d="M10 2L5 8l5 6" {...stroke}/></svg>;
    case "fx":     return <svg viewBox="0 0 16 16" style={s}><path d="M1 8 Q5 2 8 8 T15 8" {...stroke}/></svg>;
    case "wave":   return <svg viewBox="0 0 16 16" style={s}><path d="M1 8 L3 3 L6 13 L8 5 L10 11 L12 6 L14 10 L15 8" {...stroke}/></svg>;
    case "wifi":   return <svg viewBox="0 0 16 16" style={s}><path d="M2 6 Q8 0 14 6 M4 9 Q8 5 12 9 M6 12 Q8 10 10 12" {...stroke}/><circle cx="8" cy="14" r="1" fill="currentColor"/></svg>;
    case "sd":     return <svg viewBox="0 0 16 16" style={s}><path d="M4 2 H11 L14 5 V14 H4 Z" {...stroke}/></svg>;
    case "song":   return <svg viewBox="0 0 16 16" style={s}><rect x="3" y="2" width="10" height="12" rx="1" {...stroke}/><path d="M6 5h4 M6 8h4 M6 11h2" {...stroke} strokeWidth="1.6"/></svg>;
    case "live":   return <svg viewBox="0 0 16 16" style={s}><circle cx="8" cy="8" r="5" {...stroke}/><circle cx="8" cy="8" r="2" fill="currentColor"/></svg>;
    case "master": return <svg viewBox="0 0 16 16" style={s}><path d="M4 3v10 M8 5v8 M12 2v11" {...stroke}/><circle cx="4" cy="6" r="1.5" fill="currentColor"/><circle cx="8" cy="9" r="1.5" fill="currentColor"/><circle cx="12" cy="5" r="1.5" fill="currentColor"/></svg>;
    case "mute":   return <svg viewBox="0 0 16 16" style={s}><rect x="3" y="3" width="10" height="10" rx="1" fill="currentColor"/></svg>;
    case "unmute": return <svg viewBox="0 0 16 16" style={s}><rect x="3" y="3" width="10" height="10" rx="1" {...stroke}/></svg>;
    case "gear":   return <svg viewBox="0 0 16 16" style={s}><circle cx="8" cy="8" r="2.5" {...stroke}/><path d="M8 1.5v2 M8 12.5v2 M1.5 8h2 M12.5 8h2 M3.4 3.4l1.4 1.4 M11.2 11.2l1.4 1.4 M3.4 12.6l1.4-1.4 M11.2 4.8l1.4-1.4" {...stroke} strokeWidth="1.6"/></svg>;
    default: return null;
  }
};
window.V2Icon = V2Icon;

// ---------- Top bar ----------
const V2TopBar = ({ bpm = 120.0, song = "Pearl.s32", dirty = false, playing = true }) => (
  <div className="v2-topbar">
    <span className="brand">S—32</span>
    <span className="bpm-label">BPM</span>
    <span className="bpm">{bpm.toFixed(1)}</span>
    <div style={{ display: "flex", gap: 10 }}>
      <button className={`v2-btn icon sm ${playing ? "primary" : ""}`}><V2Icon name="play" size={22}/></button>
      <button className="v2-btn icon sm"><V2Icon name="stop" size={18}/></button>
    </div>
    <span className="song-name"><V2Icon name="sd" size={18} color="var(--t2)"/> {song}{dirty ? " *" : ""}</span>
  </div>
);
window.V2TopBar = V2TopBar;

// ---------- Bottom tab nav ----------
const V2Tabs = ({ active = "song" }) => {
  const tabs = [
    { id: "song",   icon: "song",   label: "SONG" },
    { id: "live",   icon: "live",   label: "LIVE" },
    { id: "master", icon: "master", label: "MASTER" },
    { id: "menu",   icon: "menu",   label: "MENU" },
  ];
  return (
    <div className="v2-tabs">
      {tabs.map(t => (
        <div key={t.id} className={`v2-tab ${active === t.id ? "active" : ""}`}>
          <span className="tab-icon"><V2Icon name={t.icon} size={30} /></span>
          <span>{t.label}</span>
        </div>
      ))}
    </div>
  );
};
window.V2Tabs = V2Tabs;

// ---------- Mini bar (sub-screens) ----------
const V2MiniBar = ({ title, right }) => (
  <div className="v2-minibar">
    <div className="back"><V2Icon name="back" size={28}/></div>
    <div className="title">{title}</div>
    <div className="spacer"/>
    {right}
  </div>
);
window.V2MiniBar = V2MiniBar;

// ---------- Big knob ----------
const V2Knob = ({ label, value, deg = -60 }) => (
  <div className="v2-knob-cell">
    <div className="v2-knob" style={{ "--knob-deg": `${deg}deg` }}/>
    <div className="v2-knob-label">{label}</div>
    <div className="v2-knob-val">{value}</div>
  </div>
);
window.V2Knob = V2Knob;

// ---------- Type chip ----------
const V2TypeChip = ({ type }) => {
  if (type === "drum")  return <span className="v2-chip drum">DRUM</span>;
  if (type === "synth") return <span className="v2-chip synth">SYNTH</span>;
  if (type === "wav")   return <span className="v2-chip wav">WAV</span>;
  return null;
};
window.V2TypeChip = V2TypeChip;
