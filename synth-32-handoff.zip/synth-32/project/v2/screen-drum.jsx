/* global React, V2MiniBar, V2Icon */

// ===================================================================
//   v2 DRUM GRID — big cells, 4 rows visible, paginated steps
// ===================================================================

const DRUM_ROWS_V2 = [
  { name: "KICK",   steps: [1,0,0,0, 1,0,0,0, 1,0,0,0, 1,0,0,0], vol: 0.95 },
  { name: "SNARE",  steps: [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0], vol: 0.85, accent: [4,12] },
  { name: "HH-CL",  steps: [1,0,1,0, 1,0,1,0, 1,0,1,0, 1,0,1,0], vol: 0.55 },
  { name: "HH-OP",  steps: [0,0,0,0, 0,0,1,0, 0,0,0,0, 0,0,1,0], vol: 0.60 },
];

const PLAYHEAD_V2 = 5;

const V2DrumGrid = () => {
  const stepW = 68;
  const rowH = 120;

  return (
    <div className="frame2">
      <V2MiniBar
        title="Drums"
        right={
          <>
            <div className="ctrl">
              <span className="ctrl-label">STEPS</span>
              <span className="ctrl-val">16</span>
              <V2Icon name="chev-d" size={18}/>
            </div>
            <div className="ctrl">
              <span className="ctrl-label">BARS</span>
              <span className="ctrl-val">2</span>
              <V2Icon name="chev-d" size={18}/>
            </div>
          </>
        }
      />

      {/* Beat header */}
      <div className="dg2-beat-header">
        <div className="dg2-label-col"/>
        {[1,2,3,4].map(beat => (
          <div key={beat} className="dg2-beat-group">
            <span className="dg2-beat-num">{beat}</span>
            <div className="dg2-beat-dots">
              {[0,1,2,3].map(s => {
                const stepIdx = (beat-1)*4 + s;
                return <div key={s} className={`dg2-beat-dot ${stepIdx === PLAYHEAD_V2 ? "play" : ""}`}/>;
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Rows */}
      <div className="dg2-body">
        {DRUM_ROWS_V2.map((row, ri) => (
          <div key={ri} className="dg2-row">
            {/* Row label */}
            <div className="dg2-label-col">
              <div className="dg2-row-name">{row.name}</div>
              <div className="dg2-row-vol">
                <div className="v2-fader" style={{ width: 64, height: 8 }}>
                  <div className="v2-fader-fill" style={{ width: `${row.vol*100}%`, background: "var(--lime)" }}/>
                </div>
              </div>
            </div>

            {/* Step groups */}
            {[0,1,2,3].map(g => (
              <div key={g} className="dg2-step-group">
                {[0,1,2,3].map(s => {
                  const stepIdx = g*4 + s;
                  const on = row.steps[stepIdx] > 0;
                  const acc = (row.accent || []).includes(stepIdx);
                  const isPlay = stepIdx === PLAYHEAD_V2;
                  return (
                    <div key={s} className={`v2-step ${on ? (acc ? "accent" : "on") : ""} ${isPlay ? "play" : ""}`}
                      style={{ width: stepW, height: stepW }}>
                      {on && <div style={{
                        position: "absolute", inset: 0,
                        background: acc ? "var(--amber)" : "var(--lime)",
                        opacity: 0.85,
                        borderRadius: 4,
                      }}/>}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* Bottom toolbar */}
      <div className="dg2-toolbar">
        <button className="v2-btn sm">COPY</button>
        <button className="v2-btn sm">PASTE</button>
        <button className="v2-btn sm">CLEAR</button>
        <div style={{ flex: 1 }}/>
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 18, color: "var(--t2)", letterSpacing: "0.12em" }}>ROWS 1—4 OF 10</span>
        <button className="v2-btn icon sm"><V2Icon name="chev-d" size={20}/></button>
      </div>

      <style>{`
        .dg2-beat-header {
          height: 48px;
          display: flex;
          align-items: center;
          background: var(--bg-2);
          border-bottom: 2px solid var(--line);
        }
        .dg2-label-col {
          width: 164px;
          flex-shrink: 0;
          height: 100%;
          display: flex;
          flex-direction: column;
          justify-content: center;
          padding: 0 20px;
          border-right: 2px solid var(--line);
        }
        .dg2-beat-group {
          flex: 1;
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 0 8px;
          border-right: 1px solid var(--line);
          height: 100%;
        }
        .dg2-beat-group:last-child { border-right: none; }
        .dg2-beat-num {
          font-family: var(--f-mono);
          font-size: 22px;
          color: var(--t1);
          font-weight: 600;
          width: 28px;
        }
        .dg2-beat-dots {
          display: flex;
          gap: 6px;
        }
        .dg2-beat-dot {
          width: 8px;
          height: 8px;
          border-radius: 4px;
          background: var(--line-2);
        }
        .dg2-beat-dot.play { background: var(--lime); box-shadow: 0 0 8px var(--lime-glow); }

        .dg2-body {
          flex: 1;
          display: flex;
          flex-direction: column;
          overflow: hidden;
        }
        .dg2-row {
          flex: 1;
          display: flex;
          align-items: center;
          border-bottom: 2px solid var(--line);
          min-height: 0;
        }
        .dg2-row-name {
          font-family: var(--f-mono);
          font-size: 24px;
          font-weight: 700;
          color: var(--t0);
          letter-spacing: 0.05em;
        }
        .dg2-row-vol {
          margin-top: 8px;
        }

        .dg2-step-group {
          flex: 1;
          display: flex;
          gap: 8px;
          padding: 8px 8px;
          justify-content: center;
          align-items: center;
          border-right: 1px solid var(--line);
          height: 100%;
        }
        .dg2-step-group:last-child { border-right: none; }

        .dg2-toolbar {
          height: 72px;
          min-height: 72px;
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 0 20px;
          background: var(--bg-2);
          border-top: 2px solid var(--line-2);
        }
      `}</style>
    </div>
  );
};

window.V2DrumGrid = V2DrumGrid;
