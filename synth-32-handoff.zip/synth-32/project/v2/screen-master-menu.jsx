/* global React, V2MiniBar, V2Tabs, V2Icon, V2Knob */

// ===================================================================
//   v2 MASTER SECTION — big knobs, meters, clock
// ===================================================================

const V2Master = () => (
  <div className="frame2">
    <div className="v2-topbar" style={{ height: 64, minHeight: 64 }}>
      <span className="brand">S—32</span>
      <span className="bpm-label">BPM</span>
      <span className="bpm" style={{ fontSize: 32 }}>120.0</span>
      <div style={{ display: "flex", gap: 10 }}>
        <button className="v2-btn icon sm primary"><V2Icon name="play" size={20}/></button>
        <button className="v2-btn icon sm"><V2Icon name="stop" size={16}/></button>
      </div>
      <span className="song-name" style={{ fontSize: 18 }}>Pearl.s32</span>
    </div>

    <div className="m2-body">

      {/* Left: volume + meters */}
      <div className="m2-panel" style={{ width: 340 }}>
        <div className="v2-section-head">VOLUME</div>
        <div style={{ display: "flex", alignItems: "center", gap: 24, padding: "0 24px" }}>
          {/* Big vertical fader */}
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
            <div style={{ height: 260, width: 40, background: "var(--bg-4)", position: "relative", borderRadius: 4 }}>
              <div style={{
                position: "absolute", left: 0, right: 0, bottom: 0, height: "82%",
                background: "linear-gradient(0deg, var(--lime) 0%, var(--lime) 70%, var(--amber) 85%, var(--red) 100%)",
                borderRadius: 4,
              }}/>
              <div style={{
                position: "absolute", left: -8, right: -8, bottom: "82%", height: 10,
                background: "var(--t0)", borderRadius: 2,
                boxShadow: "0 0 0 2px rgba(0,0,0,0.4)",
              }}/>
            </div>
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 28, color: "var(--t0)" }}>-1.6 dB</span>
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 14, letterSpacing: "0.22em", color: "var(--t2)" }}>MASTER</span>
          </div>

          {/* L/R meters */}
          <div style={{ display: "flex", gap: 8 }}>
            {[72, 65].map((v, i) => (
              <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
                <div style={{ width: 20, height: 260, background: "var(--bg-4)", position: "relative", borderRadius: 4 }}>
                  <div style={{
                    position: "absolute", left: 0, right: 0, bottom: 0, height: `${v}%`,
                    background: "linear-gradient(0deg, var(--lime) 0%, var(--lime) 60%, var(--amber) 80%, var(--red) 95%)",
                  }}/>
                </div>
                <span style={{ fontFamily: "var(--f-mono)", fontSize: 18, color: "var(--t1)" }}>{i === 0 ? "L" : "R"}</span>
              </div>
            ))}
          </div>

          {/* Pan */}
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, marginLeft: 12 }}>
            <V2Knob label="PAN" value="C" deg={0}/>
          </div>
        </div>
      </div>

      {/* Middle: FX chain (simplified) */}
      <div className="m2-panel" style={{ flex: 1 }}>
        <div className="v2-section-head">
          FX CHAIN
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 14, color: "var(--t3)" }}>4 / 6</span>
        </div>

        <div className="m2-fx-chain">
          {[
            { name: "EQ5",   on: true },
            { name: "COMP",  on: true },
            { name: "WIDTH", on: true },
            { name: "LIM",   on: true },
            { name: null },
            { name: null },
          ].map((fx, i) => (
            <div key={i} className={`m2-fx-slot ${fx.name ? "filled" : "empty"}`}>
              <span className="m2-fx-num">{i+1}</span>
              {fx.name ? (
                <span className="m2-fx-name">{fx.name}</span>
              ) : (
                <V2Icon name="plus" size={22} color="var(--t3)"/>
              )}
            </div>
          ))}
        </div>

        {/* Selected: EQ5 knobs */}
        <div className="v2-section-head" style={{ marginTop: 12 }}>
          EQ5 · SLOT 1
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 14, color: "var(--lime)" }}>● ON</span>
        </div>
        <div className="m2-fx-params">
          <V2Knob label="LOW"  value="+1.5" deg={20}/>
          <V2Knob label="LO-M" value="0"    deg={0}/>
          <V2Knob label="MID"  value="-0.5" deg={-10}/>
          <V2Knob label="HI-M" value="+1.0" deg={15}/>
          <V2Knob label="HIGH" value="+2.0" deg={40}/>
        </div>
      </div>

      {/* Right: clock */}
      <div className="m2-panel" style={{ width: 320 }}>
        <div className="v2-section-head">CLOCK</div>
        <div style={{ padding: "0 24px", display: "flex", flexDirection: "column", gap: 20 }}>

          <div className="m2-clock-row">
            <span className="m2-clock-label">BPM</span>
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 42, color: "var(--lime)", fontWeight: 500, fontVariantNumeric: "tabular-nums" }}>120.0</span>
          </div>

          <button className="v2-btn" style={{ width: "100%", justifyContent: "center" }}>TAP TEMPO</button>

          <div className="m2-clock-row">
            <span className="m2-clock-label">PPQN</span>
            <div className="v2-seg" style={{ flex: 1 }}>
              {["24","48","96","192"].map(v => (
                <div key={v} className={`v2-seg-item ${v === "96" ? "on" : ""}`} style={{ height: 52 }}>{v}</div>
              ))}
            </div>
          </div>

          <div className="m2-clock-row">
            <span className="m2-clock-label">TIME</span>
            <div className="v2-seg" style={{ flex: 1 }}>
              {["4/4","3/4","6/8"].map(v => (
                <div key={v} className={`v2-seg-item ${v === "4/4" ? "on" : ""}`} style={{ height: 52 }}>{v}</div>
              ))}
            </div>
          </div>

          <div style={{ borderTop: "2px solid var(--line)", paddingTop: 16 }}>
            <div className="m2-clock-row">
              <span className="m2-clock-label">POS</span>
              <span style={{ fontFamily: "var(--f-mono)", fontSize: 28, color: "var(--lime)" }}>027 · 03 · 12</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <V2Tabs active="master"/>

    <style>{`
      .m2-body {
        flex: 1;
        display: flex;
        gap: 2px;
        background: var(--line);
        overflow: hidden;
      }
      .m2-panel {
        background: var(--bg-1);
        display: flex;
        flex-direction: column;
      }
      .m2-fx-chain {
        display: flex;
        gap: 10px;
        padding: 0 24px;
      }
      .m2-fx-slot {
        flex: 1;
        height: 80px;
        background: var(--bg-3);
        border: 2px solid var(--line-2);
        border-radius: 8px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 6px;
        cursor: pointer;
      }
      .m2-fx-slot.empty { border-style: dashed; background: transparent; }
      .m2-fx-num {
        font-family: var(--f-mono);
        font-size: 13px;
        color: var(--t3);
      }
      .m2-fx-name {
        font-family: var(--f-mono);
        font-size: 20px;
        color: var(--t0);
        font-weight: 600;
      }
      .m2-fx-params {
        display: flex;
        gap: 24px;
        padding: 8px 24px 16px;
        justify-content: center;
      }
      .m2-clock-row {
        display: flex;
        align-items: center;
        gap: 16px;
      }
      .m2-clock-label {
        font-family: var(--f-mono);
        font-size: 16px;
        letter-spacing: 0.2em;
        color: var(--t2);
        width: 60px;
      }
    `}</style>
  </div>
);

window.V2Master = V2Master;


// ===================================================================
//   v2 MENU — big card tiles
// ===================================================================

const V2Menu = () => (
  <div className="frame2">
    <div className="v2-topbar" style={{ height: 64, minHeight: 64 }}>
      <span className="brand">S—32</span>
      <span style={{ flex: 1 }}/>
      <span style={{ fontFamily: "var(--f-mono)", fontSize: 18, color: "var(--t2)" }}>Pearl.s32 · 5 lanes · unsaved</span>
    </div>

    <div className="mn2-grid">
      {[
        { n: "01", t: "NEW SONG",   s: "Blank project",       icon: "plus", primary: true },
        { n: "02", t: "LOAD SONG",  s: "14 songs on SD",      icon: "sd" },
        { n: "03", t: "SAVE",       s: "Overwrite Pearl.s32", icon: "sd" },
        { n: "04", t: "SAVE AS…",   s: "New file",            icon: "song" },
        { n: "05", t: "SOUNDS",     s: "35 kits · 1859 files", icon: "wave" },
        { n: "06", t: "SETTINGS",   s: "Audio · WiFi · Display",icon: "gear" },
        { n: "07", t: "UPLOAD",     s: "From phone over WiFi", icon: "wifi" },
        { n: "08", t: "SAMPLE CUT", s: "Slice WAVs",           icon: "wave" },
      ].map((item, i) => (
        <div key={i} className={`mn2-card ${item.primary ? "primary" : ""}`}>
          <div className="mn2-card-icon"><V2Icon name={item.icon} size={32}/></div>
          <div>
            <div className="mn2-card-num">{item.n}</div>
            <div className="mn2-card-title">{item.t}</div>
            <div className="mn2-card-sub">{item.s}</div>
          </div>
        </div>
      ))}
    </div>

    <V2Tabs active="menu"/>

    <style>{`
      .mn2-grid {
        flex: 1;
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-template-rows: 1fr 1fr;
        gap: 2px;
        background: var(--line);
        overflow: hidden;
      }
      .mn2-card {
        background: var(--bg-1);
        padding: 20px 24px;
        display: flex;
        align-items: center;
        gap: 20px;
        cursor: pointer;
      }
      .mn2-card:active { background: var(--bg-3); }
      .mn2-card.primary { background: var(--lime-dim); }
      .mn2-card-icon { color: var(--t2); }
      .mn2-card.primary .mn2-card-icon { color: var(--lime); }
      .mn2-card-num {
        font-family: var(--f-mono);
        font-size: 13px;
        letter-spacing: 0.2em;
        color: var(--t3);
        margin-bottom: 2px;
      }
      .mn2-card.primary .mn2-card-num { color: var(--lime); }
      .mn2-card-title {
        font-family: var(--f-mono);
        font-size: 22px;
        font-weight: 700;
        color: var(--t0);
        letter-spacing: 0.06em;
      }
      .mn2-card.primary .mn2-card-title { color: var(--lime); }
      .mn2-card-sub {
        font-family: var(--f-mono);
        font-size: 15px;
        color: var(--t2);
        margin-top: 2px;
      }
    `}</style>
  </div>
);

window.V2Menu = V2Menu;
