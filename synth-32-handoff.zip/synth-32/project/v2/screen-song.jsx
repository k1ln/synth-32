/* global React, V2TopBar, V2Tabs, V2Icon, V2TypeChip */

// ===================================================================
//   v2 SONG VIEW — 4 big lane rows, bottom tab nav
// ===================================================================

const LANES_V2 = [
  { i: 1, name: "Drums",  type: "drum",  source: "AVL · Pearl",     loop: "2 bars", vol: 0.86, mute: false, playing: true,  step: 5 },
  { i: 2, name: "Bass",   type: "synth", source: "Subtractive",     loop: "4 bars", vol: 0.74, mute: false, playing: true,  step: 11 },
  { i: 3, name: "Lead",   type: "synth", source: "Super Saw",       loop: "3 bars", vol: 0.62, mute: false, playing: true,  step: 8 },
  { i: 4, name: "Pad",    type: "synth", source: "Additive",        loop: "8 bars", vol: 0.55, mute: true,  playing: false, step: 0 },
  { i: 5, name: "Loop A", type: "wav",   source: "drumloop.wav",    loop: "1 bar",  vol: 0.70, mute: false, playing: true,  step: 14 },
];

const accent = t => t === "drum" ? "var(--lime)" : t === "synth" ? "var(--cyan)" : "var(--amber)";

const V2LaneRow = ({ lane }) => (
  <div className={`v2l-row ${lane.mute ? "muted" : ""}`}>
    {/* Left color bar */}
    <div className="v2l-color" style={{ background: accent(lane.type), opacity: lane.mute ? 0.3 : 1 }}/>

    {/* Main content — name + type + source */}
    <div className="v2l-main">
      <div className="v2l-top-line">
        <span className="v2l-num">{String(lane.i).padStart(2,"0")}</span>
        <span className="v2l-name">{lane.name}</span>
        <V2TypeChip type={lane.type}/>
        <span className="v2l-source">{lane.source}</span>
      </div>
      <div className="v2l-bot-line">
        <span className="v2l-loop">{lane.loop}</span>
        <div className="v2-fader" style={{ flex: 1, maxWidth: 360 }}>
          <div className="v2-fader-fill" style={{ width: `${lane.vol*100}%`, background: accent(lane.type) }}/>
        </div>
        <span className="v2l-db">{(20*Math.log10(lane.vol||0.001)).toFixed(0)} dB</span>
        {lane.playing && (
          <div className="v2l-progress">
            <div style={{ width: `${(lane.step/16)*100}%` }}/>
          </div>
        )}
      </div>
    </div>

    {/* Mute */}
    <div className={`v2-mute ${lane.mute ? "on" : ""}`}>
      <V2Icon name={lane.mute ? "mute" : "unmute"} size={22}/>
    </div>

    {/* FX indicator */}
    <div className="v2l-fx">
      <V2Icon name="fx" size={20}/>
    </div>

    {/* Chevron */}
    <div className="v2l-chev">
      <V2Icon name="chev-r" size={22}/>
    </div>
  </div>
);

const V2LaneAdd = () => (
  <div className="v2l-row add">
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", flex: 1, gap: 16 }}>
      <V2Icon name="plus" size={24} color="var(--t2)"/>
      <span style={{ fontFamily: "var(--f-mono)", fontSize: 22, color: "var(--t2)", letterSpacing: "0.1em" }}>ADD LANE</span>
    </div>
  </div>
);

const V2SongView = () => (
  <div className="frame2">
    <V2TopBar bpm={120.0} song="Pearl.s32" dirty={true}/>

    {/* Lane list (scrollable area) */}
    <div className="v2l-body">
      {LANES_V2.map(l => <V2LaneRow key={l.i} lane={l}/>)}
      <V2LaneAdd/>
    </div>

    {/* Master strip */}
    <div className="v2l-master">
      <span className="v2l-master-label">MASTER</span>
      <div className="v2-fader" style={{ flex: 1, maxWidth: 280 }}>
        <div className="v2-fader-fill" style={{ width: "82%", background: "var(--lime)" }}/>
      </div>
      <span style={{ fontFamily: "var(--f-mono)", fontSize: 22, color: "var(--t0)", width: 80, textAlign: "right" }}>-1.6</span>
      <div style={{ width: 2, height: 32, background: "var(--line-2)", margin: "0 8px" }}/>
      <div style={{ display: "flex", flexDirection: "column", gap: 4, flex: 1, maxWidth: 300 }}>
        <div className="v2-meter-bar"><div className="v2-meter-fill" style={{ width: "72%" }}/></div>
        <div className="v2-meter-bar"><div className="v2-meter-fill" style={{ width: "65%" }}/></div>
      </div>
    </div>

    <V2Tabs active="song"/>

    <style>{`
      .v2l-body {
        flex: 1;
        overflow: hidden;
      }
      .v2l-row {
        display: flex;
        align-items: center;
        height: 100px;
        border-bottom: 2px solid var(--line);
        padding: 0;
        cursor: pointer;
        gap: 0;
      }
      .v2l-row:active { background: var(--bg-2); }
      .v2l-row.muted { opacity: 0.4; }
      .v2l-row.add {
        height: 70px;
        background: var(--bg-2);
        border-style: dashed;
        cursor: pointer;
      }
      .v2l-color {
        width: 6px;
        align-self: stretch;
        flex-shrink: 0;
      }
      .v2l-main {
        flex: 1;
        padding: 0 20px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 10px;
        min-width: 0;
      }
      .v2l-top-line {
        display: flex;
        align-items: center;
        gap: 14px;
      }
      .v2l-num {
        font-family: var(--f-mono);
        font-size: 20px;
        color: var(--t2);
        width: 40px;
      }
      .v2l-name {
        font-family: var(--f-sans);
        font-size: 28px;
        font-weight: 600;
        color: var(--t0);
      }
      .v2l-source {
        font-family: var(--f-mono);
        font-size: 18px;
        color: var(--t2);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .v2l-bot-line {
        display: flex;
        align-items: center;
        gap: 14px;
      }
      .v2l-loop {
        font-family: var(--f-mono);
        font-size: 18px;
        color: var(--t1);
        width: 90px;
      }
      .v2l-db {
        font-family: var(--f-mono);
        font-size: 18px;
        color: var(--t2);
        width: 60px;
        text-align: right;
      }
      .v2l-progress {
        width: 120px;
        height: 6px;
        background: var(--bg-4);
        border-radius: 3px;
        overflow: hidden;
      }
      .v2l-progress > div {
        height: 100%;
        background: var(--lime);
      }
      .v2l-fx, .v2l-chev {
        width: 64px;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--t2);
        border-left: 1px solid var(--line);
        flex-shrink: 0;
      }
      .v2-mute {
        margin: 0 12px;
        flex-shrink: 0;
      }

      .v2l-master {
        height: 60px;
        min-height: 60px;
        display: flex;
        align-items: center;
        padding: 0 24px;
        background: var(--bg-2);
        border-top: 2px solid var(--line-2);
        gap: 16px;
      }
      .v2l-master-label {
        font-family: var(--f-mono);
        font-size: 14px;
        letter-spacing: 0.22em;
        color: var(--t2);
      }
    `}</style>
  </div>
);

window.V2SongView = V2SongView;
