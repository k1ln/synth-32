/* global React, V2MiniBar, V2Icon, V2Tabs */

// ===================================================================
//   v2 LIVE PLAY — huge pads, big keys, one widget at a time
// ===================================================================

const PADS_V2 = [
  { name: "KICK",  hit: true },
  { name: "SNARE", hit: false },
  { name: "HH-CL", hit: false },
  { name: "HH-OP", hit: false },
  { name: "CLAP",  hit: false },
  { name: "TOM",   hit: false },
  { name: "RIDE",  hit: true },
  { name: "CRASH", hit: false },
];

const V2LivePlay = () => (
  <div className="frame2">
    <div className="v2-topbar" style={{ height: 64, minHeight: 64 }}>
      <span className="brand">S—32</span>
      <span className="bpm-label">BPM</span>
      <span className="bpm" style={{ fontSize: 32 }}>120.0</span>
      <div style={{ display: "flex", gap: 10 }}>
        <button className="v2-btn icon sm primary"><V2Icon name="play" size={20}/></button>
        <button className="v2-btn icon sm"><V2Icon name="stop" size={16}/></button>
      </div>
      <span className="song-name" style={{ fontSize: 18 }}>Pearl.s32</span>
    </div>

    {/* Lane selector tabs */}
    <div className="lv2-lane-tabs">
      {["01 DRUMS","02 BASS","03 LEAD","04 PAD","05 LOOP"].map((l, i) => (
        <div key={i} className={`lv2-lane-tab ${i === 0 ? "active" : ""}`}>{l}</div>
      ))}
    </div>

    {/* Drum pads — 2×4 grid, massive touch targets */}
    <div className="lv2-pad-grid">
      {PADS_V2.map((p, i) => (
        <div key={i} className={`lv2-pad ${p.hit ? "hit" : ""}`}>
          <span className="lv2-pad-name">{p.name}</span>
        </div>
      ))}
    </div>

    <V2Tabs active="live"/>

    <style>{`
      .lv2-lane-tabs {
        height: 52px;
        min-height: 52px;
        display: flex;
        background: var(--bg-2);
        border-bottom: 2px solid var(--line);
        overflow-x: auto;
      }
      .lv2-lane-tab {
        height: 100%;
        display: flex;
        align-items: center;
        padding: 0 24px;
        font-family: var(--f-mono);
        font-size: 18px;
        letter-spacing: 0.1em;
        color: var(--t2);
        border-right: 1px solid var(--line);
        white-space: nowrap;
        cursor: pointer;
      }
      .lv2-lane-tab.active {
        color: var(--lime);
        background: var(--lime-dim);
        font-weight: 600;
      }

      .lv2-pad-grid {
        flex: 1;
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-template-rows: 1fr 1fr;
        gap: 12px;
        padding: 16px;
      }
      .lv2-pad {
        background: var(--bg-3);
        border: 3px solid var(--line-2);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        user-select: none;
        -webkit-tap-highlight-color: transparent;
      }
      .lv2-pad:active { background: var(--bg-4); border-color: var(--line-3); }
      .lv2-pad.hit {
        background: var(--lime);
        border-color: var(--lime);
        box-shadow: 0 0 36px var(--lime-glow);
      }
      .lv2-pad-name {
        font-family: var(--f-mono);
        font-size: 24px;
        font-weight: 700;
        letter-spacing: 0.12em;
        color: var(--t0);
      }
      .lv2-pad.hit .lv2-pad-name { color: #0A0A0A; }
    `}</style>
  </div>
);

window.V2LivePlay = V2LivePlay;


// ===================================================================
//   v2 LIVE PLAY — SYNTH piano variant
// ===================================================================

const V2LivePiano = () => {
  const whiteKeys = 14; // 2 octaves
  const highlights = [4, 7]; // which white keys are pressed
  return (
    <div className="frame2">
      <div className="v2-topbar" style={{ height: 64, minHeight: 64 }}>
        <span className="brand">S—32</span>
        <span className="bpm-label">BPM</span>
        <span className="bpm" style={{ fontSize: 32 }}>120.0</span>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="v2-btn icon sm primary"><V2Icon name="play" size={20}/></button>
          <button className="v2-btn icon sm"><V2Icon name="stop" size={16}/></button>
        </div>
        <span className="song-name" style={{ fontSize: 18 }}>Pearl.s32</span>
      </div>

      {/* Lane selector */}
      <div className="lv2-lane-tabs">
        {["01 DRUMS","02 BASS","03 LEAD","04 PAD","05 LOOP"].map((l, i) => (
          <div key={i} className={`lv2-lane-tab ${i === 1 ? "active" : ""}`}>{l}</div>
        ))}
      </div>

      {/* Synth info */}
      <div style={{
        height: 60, display: "flex", alignItems: "center", padding: "0 24px", gap: 20,
        background: "var(--bg-2)", borderBottom: "2px solid var(--line)",
      }}>
        <span className="v2-chip synth">SYNTH</span>
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 24, color: "var(--t0)", fontWeight: 600 }}>Bass · Subtractive Mono</span>
        <div style={{ flex: 1 }}/>
        <button className="v2-btn sm">EDIT</button>
        <button className="v2-btn sm"><V2Icon name="fx" size={16}/> FX</button>
      </div>

      {/* Big piano keyboard */}
      <div className="lv2-piano-area">
        <div className="lv2-piano">
          {/* White keys */}
          <div className="lv2-whites">
            {Array.from({ length: whiteKeys }).map((_, i) => {
              const on = highlights.includes(i);
              const isC = i % 7 === 0;
              return (
                <div key={i} className={`lv2-white ${on ? "on" : ""}`}>
                  {isC && <span className="lv2-key-label">C{Math.floor(i/7)+3}</span>}
                </div>
              );
            })}
          </div>
          {/* Black keys overlay */}
          <div className="lv2-blacks">
            {Array.from({ length: whiteKeys }).map((_, i) => {
              const hasBlack = [0,1,3,4,5].includes(i % 7) && i < whiteKeys - 1;
              return (
                <div key={i} className="lv2-black-slot">
                  {hasBlack && <div className="lv2-black"/>}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Octave + info */}
      <div style={{
        height: 72, display: "flex", alignItems: "center", padding: "0 24px", gap: 16,
        background: "var(--bg-2)", borderTop: "2px solid var(--line-2)",
      }}>
        <button className="v2-btn sm"><V2Icon name="chev-l" size={18}/> OCT</button>
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 22, color: "var(--t1)", width: 120, textAlign: "center" }}>C3 — C5</span>
        <button className="v2-btn sm">OCT <V2Icon name="chev-r" size={18}/></button>
        <div style={{ flex: 1 }}/>
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 18, color: "var(--t2)" }}>TOUCH: 4 VOICES</span>
      </div>

      <style>{`
        .lv2-piano-area {
          flex: 1;
          display: flex;
          align-items: stretch;
          padding: 12px 16px;
          background: var(--bg-0);
        }
        .lv2-piano {
          flex: 1;
          position: relative;
          border-radius: 8px;
          overflow: hidden;
        }
        .lv2-whites {
          display: flex;
          height: 100%;
          gap: 3px;
        }
        .lv2-white {
          flex: 1;
          background: #E8E8EC;
          border-radius: 0 0 8px 8px;
          display: flex;
          align-items: flex-end;
          justify-content: center;
          padding-bottom: 14px;
          cursor: pointer;
          box-shadow: inset 0 -4px 0 rgba(0,0,0,0.06);
          position: relative;
        }
        .lv2-white.on {
          background: var(--lime);
          box-shadow: 0 0 30px var(--lime-glow), inset 0 -4px 0 rgba(0,0,0,0.1);
        }
        .lv2-key-label {
          font-family: var(--f-mono);
          font-size: 16px;
          color: #74747D;
          font-weight: 600;
        }
        .lv2-white.on .lv2-key-label { color: #0A0A0A; }

        .lv2-blacks {
          position: absolute;
          inset: 0;
          display: flex;
          pointer-events: none;
        }
        .lv2-black-slot {
          flex: 1;
          position: relative;
        }
        .lv2-black {
          position: absolute;
          right: -22%;
          top: 0;
          width: 44%;
          height: 58%;
          background: #0A0A0C;
          border-radius: 0 0 6px 6px;
          pointer-events: auto;
          cursor: pointer;
          box-shadow: 0 3px 0 rgba(0,0,0,0.5);
          z-index: 2;
        }
      `}</style>
    </div>
  );
};

window.V2LivePiano = V2LivePiano;
