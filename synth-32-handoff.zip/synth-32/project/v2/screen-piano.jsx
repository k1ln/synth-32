/* global React, V2MiniBar, V2Icon */

// ===================================================================
//   v2 PIANO ROLL — big notes, fewer octaves, touch-friendly
// ===================================================================

const NOTE_NAMES_V2 = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
const isBlack2 = n => [1,3,6,8,10].includes(n % 12);
const noteLabel2 = n => `${NOTE_NAMES_V2[n%12]}${Math.floor(n/12)-1}`;

const TOP_NOTE_V2 = 64; // E4
const ROW_CT_V2 = 12;   // 1 octave visible
const BARS_V2 = 2;

const NOTES_V2 = [
  { tick: 0,    len: 96,  note: 52, vel: 100 },
  { tick: 96,   len: 48,  note: 55, vel: 90  },
  { tick: 144,  len: 48,  note: 59, vel: 95  },
  { tick: 192,  len: 96,  note: 64, vel: 110 },
  { tick: 288,  len: 48,  note: 62, vel: 88  },
  { tick: 336,  len: 48,  note: 59, vel: 90  },
  { tick: 384,  len: 96,  note: 52, vel: 100 },
  { tick: 480,  len: 48,  note: 55, vel: 92  },
  { tick: 576,  len: 96,  note: 60, vel: 105 },
  { tick: 672,  len: 48,  note: 62, vel: 95  },
];

const PH_TICK_V2 = 220;
const TICKS_V2 = 384 * BARS_V2;

const V2PianoRoll = () => {
  const keyW = 100;
  const rollW = 1280 - keyW;
  const rowH = 42;  // px per semitone
  const tickToPx = t => (t / TICKS_V2) * rollW;

  return (
    <div className="frame2">
      <V2MiniBar
        title="Bass"
        right={
          <>
            <div className="ctrl">
              <span className="ctrl-label">SYNTH</span>
              <span className="ctrl-val">Subtractive</span>
              <V2Icon name="chev-d" size={18}/>
            </div>
            <div className="ctrl">
              <span className="ctrl-label">SNAP</span>
              <span className="ctrl-val">1/16</span>
              <V2Icon name="chev-d" size={18}/>
            </div>
          </>
        }
      />

      {/* Bar header */}
      <div className="pr2-bar-header">
        <div style={{ width: keyW, borderRight: "2px solid var(--line)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <V2Icon name="wave" size={20} color="var(--t2)"/>
        </div>
        <div style={{ flex: 1, position: "relative" }}>
          {Array.from({ length: BARS_V2 * 4 }).map((_, beat) => {
            const isBar = beat % 4 === 0;
            const x = (beat / (BARS_V2 * 4)) * rollW;
            return (
              <div key={beat} style={{
                position: "absolute", left: x, top: 0, bottom: 0,
                borderLeft: `2px solid ${isBar ? "var(--line-3)" : "var(--line)"}`,
                padding: "8px 0 0 10px",
                fontFamily: "var(--f-mono)",
                fontSize: 16,
                color: isBar ? "var(--t1)" : "var(--t3)",
                letterSpacing: "0.08em",
              }}>
                {isBar ? `BAR ${beat/4 + 1}` : `${(beat%4) + 1}`}
              </div>
            );
          })}
          {/* Playhead marker */}
          <div style={{ position: "absolute", left: tickToPx(PH_TICK_V2), top: 0, bottom: 0, width: 2, background: "var(--lime)" }}/>
        </div>
      </div>

      {/* Roll body */}
      <div style={{ flex: 1, display: "flex", position: "relative", overflow: "hidden" }}>
        {/* Piano key column */}
        <div style={{ width: keyW, borderRight: "2px solid var(--line-2)", background: "var(--bg-2)", flexShrink: 0 }}>
          {Array.from({ length: ROW_CT_V2 }).map((_, i) => {
            const n = TOP_NOTE_V2 - i;
            const blk = isBlack2(n);
            return (
              <div key={i} style={{
                height: rowH,
                display: "flex",
                alignItems: "center",
                padding: "0 14px",
                background: blk ? "var(--bg-1)" : "var(--bg-2)",
                borderBottom: "1px solid var(--line)",
                fontFamily: "var(--f-mono)",
                fontSize: 18,
                color: blk ? "var(--t2)" : "var(--t0)",
                fontWeight: blk ? 400 : 500,
              }}>
                {noteLabel2(n)}
              </div>
            );
          })}
        </div>

        {/* Note grid */}
        <div style={{ flex: 1, position: "relative", background: "var(--bg-1)" }}>
          {/* Row backgrounds */}
          {Array.from({ length: ROW_CT_V2 }).map((_, i) => {
            const n = TOP_NOTE_V2 - i;
            return (
              <div key={i} style={{
                position: "absolute", left: 0, right: 0,
                top: i * rowH, height: rowH,
                background: isBlack2(n) ? "rgba(255,255,255,0.015)" : "transparent",
                borderBottom: "1px solid rgba(255,255,255,0.03)",
              }}/>
            );
          })}

          {/* Vertical grid (16ths) */}
          {Array.from({ length: BARS_V2 * 16 }).map((_, i) => {
            const x = (i / (BARS_V2 * 16)) * rollW;
            const isBar = i % 16 === 0;
            const isBeat = i % 4 === 0;
            return (
              <div key={i} style={{
                position: "absolute", left: x, top: 0, bottom: 0,
                width: isBar ? 2 : 1,
                background: isBar ? "var(--line-3)" : isBeat ? "var(--line-2)" : "var(--line)",
                opacity: isBar ? 1 : isBeat ? 0.7 : 0.4,
              }}/>
            );
          })}

          {/* Notes */}
          {NOTES_V2.map((nt, i) => {
            const rowIdx = TOP_NOTE_V2 - nt.note;
            if (rowIdx < 0 || rowIdx >= ROW_CT_V2) return null;
            const x = tickToPx(nt.tick);
            const w = tickToPx(nt.len);
            const y = rowIdx * rowH;
            const br = 0.5 + (nt.vel / 127) * 0.5;
            return (
              <div key={i} style={{
                position: "absolute",
                left: x, top: y + 3,
                width: w - 3, height: rowH - 6,
                background: `rgba(199,245,70,${br})`,
                borderLeft: "3px solid var(--lime)",
                borderRadius: 4,
                boxShadow: "0 0 14px rgba(199,245,70,0.2)",
                display: "flex",
                alignItems: "center",
                padding: "0 8px",
              }}>
                <span style={{
                  fontFamily: "var(--f-mono)", fontSize: 14, color: "rgba(0,0,0,0.7)",
                  fontWeight: 700,
                }}>{noteLabel2(nt.note)}</span>
              </div>
            );
          })}

          {/* Playhead */}
          <div style={{
            position: "absolute", left: tickToPx(PH_TICK_V2), top: 0, bottom: 0,
            width: 2, background: "var(--lime)", boxShadow: "0 0 12px var(--lime)",
          }}/>
        </div>
      </div>

      {/* Bottom: octave nav + zoom + actions */}
      <div className="pr2-toolbar">
        <button className="v2-btn sm"><V2Icon name="chev-l" size={18}/> OCT</button>
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 20, color: "var(--t1)", width: 100, textAlign: "center" }}>
          C3—C4
        </span>
        <button className="v2-btn sm">OCT <V2Icon name="chev-r" size={18}/></button>
        <div style={{ width: 2, height: 32, background: "var(--line-2)", margin: "0 8px" }}/>
        <button className="v2-btn sm"><V2Icon name="plus" size={16}/></button>
        <button className="v2-btn sm"><V2Icon name="fx" size={18}/> FX</button>
        <div style={{ flex: 1 }}/>
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 18, color: "var(--lime)" }}>
          ▸ 1 · 02 · 12
        </span>
      </div>

      <style>{`
        .pr2-bar-header {
          height: 46px;
          display: flex;
          background: var(--bg-2);
          border-bottom: 2px solid var(--line);
          flex-shrink: 0;
        }
        .pr2-toolbar {
          height: 76px;
          min-height: 76px;
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 0 20px;
          background: var(--bg-2);
          border-top: 2px solid var(--line-2);
        }
      `}</style>
    </div>
  );
};

window.V2PianoRoll = V2PianoRoll;
