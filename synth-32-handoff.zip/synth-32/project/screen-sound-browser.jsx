/* global React, MiniTopBar, Drop, Icon */

// ===================================================================
//   SOUND BROWSER
// ===================================================================

const KITS = [
  { name: "AVL · Pearl-22", count: 36, sel: true },
  { name: "AVL · BlondeBop", count: 28 },
  { name: "AVL · BuskmansHol", count: 41 },
  { name: "AVL · Sonor-Phonic", count: 33 },
  { name: "BJA · Pacific", count: 24 },
  { name: "Boss · DR-110", count: 18 },
  { name: "Classic · 606", count: 16 },
  { name: "Classic · 626", count: 22 },
  { name: "Classic · 808", count: 25 },
  { name: "Classic · 909", count: 28 },
  { name: "Korg · KPR-77", count: 14 },
  { name: "Linn · LM-1", count: 19 },
  { name: "Linn · LinnDrum", count: 23 },
  { name: "MFB · Tanzbär", count: 30 },
  { name: "Oberheim · DMX", count: 18 },
  { name: "Roland · TR-707", count: 24 },
  { name: "Roland · TR-727", count: 22 },
  { name: "Simmons · SDS-V", count: 20 },
  { name: "User · Recorded", count: 7 },
];

const FILES = [
  { n: "36 — Pearl-22-Kick-1.wav",      sec: 0.42, sel: true },
  { n: "36 — Pearl-22-Kick-2.wav",      sec: 0.51 },
  { n: "36 — Pearl-22-Kick-3.wav",      sec: 0.39 },
  { n: "37 — Pearl-14-Snare-1.wav",     sec: 0.62 },
  { n: "37 — Pearl-14-Snare-2.wav",     sec: 0.58 },
  { n: "38 — Pearl-14-Side-Stick.wav",  sec: 0.21 },
  { n: "42 — Pearl-Hat-Cl-1.wav",       sec: 0.18 },
  { n: "42 — Pearl-Hat-Cl-2.wav",       sec: 0.16 },
  { n: "44 — Pearl-Hat-Ped.wav",        sec: 0.25 },
  { n: "46 — Pearl-Hat-Op-1.wav",       sec: 1.42 },
  { n: "46 — Pearl-Hat-Op-2.wav",       sec: 1.31 },
  { n: "48 — Pearl-Tom-Hi-1.wav",       sec: 0.74 },
  { n: "47 — Pearl-Tom-Mid-1.wav",      sec: 0.88 },
  { n: "45 — Pearl-Tom-Lo-1.wav",       sec: 1.04 },
  { n: "49 — Pearl-Crash-1.wav",        sec: 3.21 },
  { n: "51 — Pearl-Ride-1.wav",         sec: 2.10 },
];

const Waveform = ({ seed = 1, color = "var(--amber)", height = 18, width = 80 }) => {
  const pts = Array.from({ length: 40 }).map((_, i) => Math.abs(Math.sin(i * 0.41 + seed) * 0.5 + Math.sin(i * 0.13 + seed*2) * 0.3));
  return (
    <svg viewBox={`0 0 80 ${height}`} preserveAspectRatio="none" style={{ width, height }}>
      {pts.map((v, i) => (
        <rect key={i} x={i*2} y={height/2 - v*height*0.7} width="1.5" height={v*height*1.4} fill={color} opacity="0.85"/>
      ))}
    </svg>
  );
};

const SoundBrowser = () => (
  <div className="frame">
    <MiniTopBar
      title="Sound Browser"
      right={
        <>
          <div className="topbar-cell tight" style={{ width: 280 }}>
            <Icon name="sd" size={12} color="var(--t2)" />
            <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--t1)", textTransform: "none", letterSpacing: 0 }}>
              /sounds  ·  35 kits  ·  1859 files  ·  437 MB
            </span>
          </div>
          <button className="topbar-cell action" style={{ background: "transparent", border: "none", borderLeft: "1px solid var(--line)", borderRight: "1px solid var(--line)", cursor: "pointer", color: "var(--t0)" }}>
            <Icon name="plus" size={12}/> UPLOAD
          </button>
        </>
      }
    />

    <div className="sb-grid">
      {/* Kit column */}
      <div className="sb-col">
        <div className="section-head" style={{ display: "flex", justifyContent: "space-between" }}>
          KITS
          <input className="sb-search" placeholder="Search kits…" />
        </div>
        <div className="sb-list">
          {KITS.map((k, i) => (
            <div key={i} className={`sb-kit ${k.sel ? "sel" : ""}`}>
              <span className="num" style={{ width: 24, color: "var(--t3)" }}>{String(i+1).padStart(2,"0")}</span>
              <span style={{ flex: 1, color: k.sel ? "var(--lime)" : "var(--t0)", fontFamily: "var(--f-mono)", fontSize: 12 }}>{k.name}</span>
              <span className="num" style={{ fontSize: 10, color: "var(--t2)" }}>{k.count} files</span>
              {k.sel && <Icon name="chev-r" size={12}/>}
            </div>
          ))}
        </div>
      </div>

      {/* File column */}
      <div className="sb-col" style={{ flex: 1 }}>
        <div className="section-head" style={{ display: "flex", justifyContent: "space-between" }}>
          <span>FILES · AVL · PEARL-22</span>
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--t3)" }}>36 files · 12.4 MB</span>
        </div>
        <div className="sb-list">
          {FILES.map((f, i) => (
            <div key={i} className={`sb-file ${f.sel ? "sel" : ""}`}>
              <button className="prev-btn" title="Preview">
                <Icon name="play" size={10}/>
              </button>
              <span style={{ flex: 1, fontFamily: "var(--f-mono)", fontSize: 12, color: f.sel ? "var(--lime)" : "var(--t0)" }}>{f.n}</span>
              <Waveform seed={i+1} color={f.sel ? "var(--lime)" : "var(--amber)"} />
              <span className="num" style={{ fontSize: 10, color: "var(--t2)", width: 50, textAlign: "right" }}>
                {f.sec.toFixed(2)}s
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Detail / select column */}
      <div className="sb-col" style={{ width: 320, background: "var(--bg-2)" }}>
        <div className="section-head">SELECTION</div>
        <div style={{ padding: "0 16px", display: "flex", flexDirection: "column", gap: 14 }}>

          {/* Selected file detail */}
          <div className="sb-detail">
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 13, color: "var(--lime)", fontWeight: 600, marginBottom: 4 }}>
              Pearl-22-Kick-1
            </div>
            <div style={{ fontFamily: "var(--f-mono)", fontSize: 10, color: "var(--t2)", letterSpacing: 0 }}>
              /sounds/avl-pearl-22/36-pearl-22-kick-1.wav
            </div>
          </div>

          {/* Big waveform */}
          <div style={{ height: 80, background: "var(--bg-1)", border: "1px solid var(--line-2)", borderRadius: 4, position: "relative", overflow: "hidden" }}>
            <Waveform seed={1} color="var(--lime)" height={80} width={290} />
          </div>

          {/* Metadata table */}
          <div className="sb-meta">
            <div><span>FORMAT</span><span className="num">WAV · 16-bit PCM</span></div>
            <div><span>SAMPLE RATE</span><span className="num">44.100 kHz</span></div>
            <div><span>CHANNELS</span><span className="num">MONO</span></div>
            <div><span>DURATION</span><span className="num">0.42 s</span></div>
            <div><span>SIZE</span><span className="num">38.2 KB</span></div>
            <div><span>PEAK</span><span className="num">-0.4 dBFS</span></div>
            <div><span>SHA256</span><span className="num" style={{ fontSize: 9 }}>a3f8…b942</span></div>
          </div>

          {/* Actions */}
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <button className="btn primary lg" style={{ width: "100%", justifyContent: "center" }}>
              <Icon name="chev-r" size={12}/> ASSIGN TO ROW
            </button>
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn" style={{ flex: 1, justifyContent: "center" }}><Icon name="play" size={11}/> PREVIEW</button>
              <button className="btn" style={{ flex: 1, justifyContent: "center" }}><Icon name="wave" size={11}/> CUT</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <style>{`
      .sb-grid {
        flex: 1;
        display: flex;
        gap: 1px;
        background: var(--line);
        overflow: hidden;
      }
      .sb-col {
        background: var(--bg-1);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        width: 280px;
      }
      .sb-list {
        flex: 1;
        overflow: hidden;
      }
      .sb-search {
        background: var(--bg-3);
        border: 1px solid var(--line-2);
        color: var(--t1);
        font-family: var(--f-mono);
        font-size: 10px;
        padding: 4px 8px;
        border-radius: 2px;
        width: 130px;
        outline: none;
      }
      .sb-kit, .sb-file {
        display: flex;
        align-items: center;
        gap: 12px;
        height: 36px;
        padding: 0 14px;
        border-bottom: 1px solid var(--line);
        cursor: pointer;
      }
      .sb-kit:hover, .sb-file:hover { background: var(--bg-2); }
      .sb-kit.sel, .sb-file.sel {
        background: var(--lime-dim);
        border-left: 2px solid var(--lime);
        padding-left: 12px;
      }
      .prev-btn {
        width: 22px; height: 22px;
        background: var(--bg-3);
        border: 1px solid var(--line-2);
        color: var(--lime);
        display: flex; align-items: center; justify-content: center;
        cursor: pointer;
        border-radius: 50%;
      }
      .sb-file.sel .prev-btn { background: var(--lime); color: #0A0A0A; }
      .sb-detail {
        background: var(--bg-3);
        border: 1px solid var(--line-2);
        border-radius: 4px;
        padding: 10px 12px;
      }
      .sb-meta { display: flex; flex-direction: column; gap: 6px; padding: 8px 0; border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); }
      .sb-meta > div {
        display: flex;
        justify-content: space-between;
        font-family: var(--f-mono);
        font-size: 10px;
      }
      .sb-meta > div > span:first-child { color: var(--t2); letter-spacing: 0.1em; }
      .sb-meta > div > span:last-child  { color: var(--t0); }
    `}</style>
  </div>
);

window.SoundBrowser = SoundBrowser;


// ===================================================================
//   SAMPLE CUTTER
// ===================================================================

const SampleCutter = () => (
  <div className="frame">
    <MiniTopBar
      title="Sample Cutter"
      right={
        <button className="topbar-cell action" style={{ background: "var(--lime)", color: "#0A0A0A", border: "none", padding: "0 18px", fontWeight: 600, cursor: "pointer" }}>
          <Icon name="sd" size={12}/> SAVE 4 CUTS
        </button>
      }
    />

    <div style={{ flex: 1, display: "flex", flexDirection: "column", padding: 16, gap: 16, overflow: "hidden" }}>

      {/* File row */}
      <div className="sc-files">
        <div className="sc-file-row">
          <span className="bb-label">SOURCE</span>
          <div className="field" style={{ flex: 1 }}>
            <Icon name="wave" size={11} color="var(--amber)"/>
            <span style={{ color: "var(--t0)" }}>sounds/recordings/jam_session_2026-05-26.wav</span>
            <span className="num" style={{ marginLeft: "auto", color: "var(--t2)", fontSize: 11 }}>1:23.456 · 14.2 MB · 44.1 kHz · stereo</span>
          </div>
          <button className="btn">BROWSE</button>
        </div>
        <div className="sc-file-row" style={{ marginTop: 10 }}>
          <span className="bb-label">DEST</span>
          <div className="field" style={{ flex: 1 }}>
            <Icon name="sd" size={11} color="var(--lime)"/>
            <span style={{ color: "var(--t0)" }}>sounds/jam-cuts/</span>
          </div>
          <button className="btn"><Icon name="plus" size={10}/> NEW FOLDER</button>
        </div>
      </div>

      {/* Waveform */}
      <div className="sc-wave">
        <svg viewBox="0 0 1248 200" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
          {Array.from({ length: 312 }).map((_, i) => {
            const h = 30 + Math.abs(Math.sin(i * 0.13) * 60) + Math.abs(Math.sin(i * 0.07 + 1) * 40);
            return <rect key={i} x={i*4} y={100 - h/2} width="2.5" height={h} fill="var(--amber)" opacity="0.55"/>;
          })}
        </svg>

        {/* Time ruler */}
        <div className="sc-ruler">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} style={{ flex: 1, borderLeft: "1px solid var(--line-2)", padding: "2px 0 0 4px", fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--t3)" }}>
              0:{(i*10).toString().padStart(2, "0")}.000
            </div>
          ))}
        </div>

        {/* Regions */}
        {[
          { l: 4,  w: 12, n: 1, sel: false },
          { l: 22, w: 14, n: 2, sel: true  },
          { l: 44, w: 10, n: 3, sel: false },
          { l: 68, w: 16, n: 4, sel: false },
        ].map((r, i) => (
          <div key={i} className={`sc-region ${r.sel ? "sel" : ""}`} style={{ left: `${r.l}%`, width: `${r.w}%` }}>
            <span className="sc-region-handle l" />
            <span className="sc-region-label">CUT-{String(r.n).padStart(3,"0")}</span>
            <span className="sc-region-handle r" />
          </div>
        ))}

        {/* Playhead */}
        <div style={{ position: "absolute", left: "27%", top: 0, bottom: 0, width: 1, background: "var(--lime)", boxShadow: "0 0 8px var(--lime)" }}/>
      </div>

      {/* Transport */}
      <div className="sc-transport">
        <button className="btn primary"><Icon name="play" size={12}/> PLAY</button>
        <button className="btn"><Icon name="stop" size={12}/> STOP</button>
        <div className="bb-divider"/>
        <span className="num" style={{ color: "var(--lime)", fontSize: 14 }}>0:22.480</span>
        <span className="num" style={{ color: "var(--t3)" }}>/</span>
        <span className="num" style={{ color: "var(--t1)", fontSize: 14 }}>1:23.456</span>
        <div style={{ flex: 1 }}/>
        <button className="btn"><Icon name="plus" size={11}/> ADD REGION AT PLAYHEAD</button>
        <button className="btn ghost">SNAP · 1/16</button>
        <button className="btn ghost">ZOOM · 1×</button>
      </div>

      {/* Region table */}
      <div className="sc-table-wrap">
        <div className="section-head" style={{ padding: "10px 16px 4px" }}>
          REGIONS · 4
          <span style={{ fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--t3)" }}>output: 16-bit · mono · 44.1 kHz · 4 files · est. 240 KB</span>
        </div>
        <div className="sc-table">
          <div className="sc-thead">
            <div style={{ width: 50 }}>#</div>
            <div style={{ width: 110 }}>START</div>
            <div style={{ width: 110 }}>END</div>
            <div style={{ width: 110 }}>DURATION</div>
            <div style={{ flex: 1 }}>OUTPUT FILENAME</div>
            <div style={{ width: 100 }}>ACTIONS</div>
          </div>
          {[
            { s: "0:02.140", e: "0:11.200", d: "9.060s", n: "cut-001.wav" },
            { s: "0:13.880", e: "0:24.640", d: "10.760s", n: "cut-002.wav", sel: true },
            { s: "0:31.000", e: "0:38.500", d: "7.500s", n: "cut-003.wav" },
            { s: "0:43.100", e: "0:56.220", d: "13.120s", n: "cut-004.wav" },
          ].map((r, i) => (
            <div key={i} className={`sc-trow ${r.sel ? "sel" : ""}`}>
              <div style={{ width: 50, fontFamily: "var(--f-mono)", color: r.sel ? "var(--lime)" : "var(--t1)" }}>{String(i+1).padStart(2,"0")}</div>
              <div style={{ width: 110, fontFamily: "var(--f-mono)", color: "var(--t1)" }}>{r.s}</div>
              <div style={{ width: 110, fontFamily: "var(--f-mono)", color: "var(--t1)" }}>{r.e}</div>
              <div style={{ width: 110, fontFamily: "var(--f-mono)", color: "var(--t0)" }}>{r.d}</div>
              <div style={{ flex: 1, fontFamily: "var(--f-mono)", color: r.sel ? "var(--lime)" : "var(--t0)" }}>{r.n}</div>
              <div style={{ width: 100, display: "flex", gap: 6 }}>
                <button className="mini-btn"><Icon name="play" size={9}/></button>
                <button className="mini-btn">EDIT</button>
                <button className="mini-btn" style={{ color: "var(--red)" }}><Icon name="x" size={9}/></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>

    <style>{`
      .sc-files { display: flex; flex-direction: column; }
      .sc-file-row { display: flex; align-items: center; gap: 12px; }
      .sc-file-row .bb-label { width: 60px; font-family: var(--f-mono); font-size: 9px; letter-spacing: 0.18em; text-transform: uppercase; color: var(--t2); }
      .sc-wave {
        height: 200px;
        background: var(--bg-2);
        border: 1px solid var(--line-2);
        border-radius: 4px;
        position: relative;
        overflow: hidden;
      }
      .sc-ruler {
        position: absolute;
        left: 0; right: 0;
        bottom: 0;
        height: 18px;
        background: var(--bg-3);
        border-top: 1px solid var(--line-2);
        display: flex;
      }
      .sc-region {
        position: absolute;
        top: 4px; bottom: 22px;
        background: rgba(91,196,255,0.16);
        border: 1px solid var(--cyan);
        border-radius: 2px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
      }
      .sc-region.sel {
        background: var(--lime-dim);
        border-color: var(--lime);
        box-shadow: 0 0 0 1px var(--lime), 0 0 16px var(--lime-glow);
      }
      .sc-region-handle {
        position: absolute;
        top: -2px; bottom: -2px;
        width: 4px;
        background: var(--cyan);
        cursor: ew-resize;
      }
      .sc-region.sel .sc-region-handle { background: var(--lime); }
      .sc-region-handle.l { left: -2px; }
      .sc-region-handle.r { right: -2px; }
      .sc-region-label {
        font-family: var(--f-mono);
        font-size: 10px;
        color: var(--cyan);
        letter-spacing: 0.08em;
        font-weight: 600;
        background: rgba(0,0,0,0.4);
        padding: 2px 6px;
        border-radius: 2px;
      }
      .sc-region.sel .sc-region-label { color: var(--lime); }

      .sc-transport { display: flex; align-items: center; gap: 10px; }
      .bb-divider { width: 1px; height: 24px; background: var(--line-2); }

      .sc-table-wrap {
        flex: 1;
        background: var(--bg-2);
        border: 1px solid var(--line-2);
        border-radius: 4px;
        overflow: hidden;
        display: flex;
        flex-direction: column;
      }
      .sc-table { flex: 1; overflow: hidden; }
      .sc-thead, .sc-trow {
        display: flex;
        align-items: center;
        height: 36px;
        padding: 0 16px;
        gap: 12px;
        border-bottom: 1px solid var(--line);
      }
      .sc-thead {
        font-family: var(--f-mono);
        font-size: 9px;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        color: var(--t2);
        background: var(--bg-3);
      }
      .sc-trow { font-size: 12px; }
      .sc-trow.sel { background: var(--lime-dim); }
      .sc-trow .mini-btn {
        width: 28px; height: 24px;
        background: var(--bg-3);
        border: 1px solid var(--line-2);
        color: var(--t1);
        font-family: var(--f-mono);
        font-size: 9px;
        cursor: pointer;
        border-radius: 2px;
        display: flex; align-items: center; justify-content: center;
      }
    `}</style>
  </div>
);

window.SampleCutter = SampleCutter;
